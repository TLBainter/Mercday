# UX Handoff Log

Each entry = one package delivered to the Godot GUI agent. The newest entry is the baseline for the next `/download-ux-guide`.

## 2026-09-23 — Initial full handoff (baseline v1)
**Package:** `design_handoff_mercenary_gui/` (full, not a delta)
**Baseline snapshot:** `design_handoff_mercenary_gui/reference_html/` (use this to diff future changes)

Delivered:
- Screens: Game HUD, Merc Viewer (8 tabs incl. Metrics), Contract Viewer, Dispatch Window, Metrics Viewer
- README.md (screens, tokens, deployment walkthrough), SCENES.md (all reusable scenes + exports + autoloads), DATA.md (Resources + game rules), ASSETS.md (icons, fonts, theme StyleBoxes, placeholders)
- assets/icons/ — 20 PNGs (12 UI icons + 8 Merc Viewer tab icons)
- sample_data/ — sample_data.json, dispatch_scoring.js, metrics_history_generator.js

Feature state at this date:
- Accept → Dispatch (5 slots, dashed optional slots) → Active contract (crew portraits, payout/odds tooltips, Estimated Return Time)
- GameState shared store: merc status derived from active teams across viewers
- Metrics: Merc/Contract/Guild graphs, draw-on animation, Y-focus, Day/Week/Month/Quarter rules, contract-type filter
- HUD: My Mercs, My Contracts, My Metrics (6 empty slots)

Known open items: time progression/returns, 6 HUD buttons + Settings, real portraits/contract art/sigils, money bar values.

## 2026-09-24 — Metrics Viewer complete guide (scoped full guide)
**Package:** `design_handoff_metrics_2026-09-24/` (complete for Metrics only; supersedes Metrics sections of baseline v1)
**Baseline snapshot:** `design_handoff_metrics_2026-09-24/reference_html/Metrics Viewer.dc.html` for Metrics Viewer, Feature Lock, Locked Page. All other screens still diff against `design_handoff_mercenary_gui/reference_html/`.

Delivered: README (layout, every state, locks), SCENES, DATA (metric defs, aggregation, compare math, entitlements), 31 screenshots, 6 icons.
New vs v1: Investment Portfolio, Vacation Days Taken, All Mercs averages mode, Show Averages + compare arrows, Merc Comparison, all Metrics locks (marked Phase 2 / optional for now).
Fix shipped: embedded Metrics tab no longer shows a double LockedPage.
Note: Metrics Viewer changed after this package (icon tabs, Period/Scale dropdowns, tabs attached to chart, compare-popup fix). Those changes are still undelivered; the next Metrics delta should diff against this snapshot.

## 2026-09-25 — Dispatch Window complete guide (scoped full guide)
**Package:** `design_handoff_dispatch_2026-09-25/` (complete for Dispatch only; supersedes Dispatch sections of baseline v1)
**Baseline snapshot:** `design_handoff_dispatch_2026-09-25/reference_html/Dispatch Window.dc.html` for Dispatch Window.

Delivered: README (layout, every state and dialog), SCENES, DATA (travel, scoring, odds, Optimize, preview, payload), 23 screenshots, dispatch_scoring.js.
New vs v1: Mercenary Bonus + Guild Cut preview rows, notes glyph on costs; entry point Accept/Reject recolored.
Undelivered elsewhere (not in this package): Merc Viewer Coaching/PIP dialog + Lifepath fix, Subscription Viewer (Skill/Combat PIP tiers, category progress icons), HUD "My Mercday" rename.

## 2026-09-25 — Update (reworked): Bazaar + Legal + Promotions + Hiring + all changes (delta)
**Package:** `design_handoff_update_2026-09-25/` (delta since the Dispatch guide; the first version of this package was never deployed, so this rework supersedes it and contains everything). Parts A–D (original) → E changes → F Legal → G Promotions + Hiring → H verify. Runbook: `RUNBOOK.md`.
**Baseline snapshot:** `design_handoff_update_2026-09-25/baseline_snapshot/` (all 20 screens/components) — diff source for the next update.

Delivered: README (91 screenshots), SCENES_DELTA, DATA_DELTA, 50 icons, reference_html (20 DCs + support.js, legal-data.js, promo-core.js, fit-frame.js).
Original (A–D): HUD My Mercday rename + locked My Bazaar; Contract Accept/Reject colors; Metrics icon tabs + Period/Scale dropdowns; Merc Viewer Coaching; Customize rule-based layout; Bazaar (Shop/Cart/Orders).
Added in rework: HUD 3×3 re-layout (Promotions, Finance, Legal, Bazaar, Metrics), gavel icon, tooltip z-order; Finance › Hiring tab + Odd Jobs gate on Request a Loan; Merc Viewer applicant mode + XP tooltip fix; Customize full re-layout (Limits/Bazaar arms, two bottom branches, single leg renderer, exitDy, cost billing), new upgrades (Operations/Teleportation Permits, Representation, Advisory Counsel, Who Knows a Guy, Discrimination IV Hiring Discrimination); shared OddJobCrew, TextEntryDialog, ConfirmDialog, FeatureLock label mode, unified NotificationDot; My Legal (Permits/Fines/Bailout, Review, Odd Jobs); My Promotions (Advertise Job/Guild, CampaignBuilder); Hiring (filters, sort, offer/counter-offer, applicant view).
Open: tree upgrades for Direct Sale/Radio/Sponsorship; applicant generation + timing; time advancement (Odd Jobs, campaigns, counter-offers); Settings (Odd Job Default Bonus); real art.

## 2026-09-26 — Update: 2026-09-25 package + Part I (delta; replaces the undeployed 09-25 update)
**Package:** `design_handoff_update_2026-09-26/` (the 09-25 update was never given to the implementer; this one contains all of it — Parts A–H unchanged — plus Part I and Part J). Runbook: `RUNBOOK.md` (steps 13–19 new).
**Baseline snapshot:** `design_handoff_update_2026-09-26/baseline_snapshot/` (all 20 screens/components) — diff source for the next update.

Delivered: README (106 screenshots — outdated 09-25 shots removed or re-captured; 92–121 new), SCENES_DELTA + DATA_DELTA (Part I appendices), 60 icons (promo tab icons renamed promo_tab_job_ads / promo_tab_guild_ads; 10 new: 6 Promotions tree, "!" and skull marks, skull/bars result overlays), reference_html (20 DCs + support.js, legal-data.js, promo-core.js, fit-frame.js).
Part I: Customize Promotions category (Promotions, Promo Methods, Long Promos, Marketing Agency, Guild Promo), Limits up-fork, Bazaar down-fork, completed categories turn green (box + line to Base); entitlements for all promo upgrades; HUD Promotions lock by upgrade, neutral "Contract Complete" notification, negative money fly; Promotions: Job Ads / Guild Ads, sort + filter, 9 sample ads, new card stats, Infinite campaigns, pro-rated End refund (underlined), duration stepper + unit dropdown (Long Promos cap), effectiveness + Marketing Agency, checkboxes, Radio coverage, Sponsorship single location, Guild Promo tier locks, View Applicants → Finance › Hiring; Finance Ads expense; Contract FAILED + no-spoiler results (fates → SUCCESS!/FAILURE verdict that docks above the title → XP → money → Continue); unified SortDirToggle on every list.
Open: effect → generation math; applicant generation + timing; time advancement (Odd Jobs, campaigns, monthly billing, counter-offers); ContractResolver; Settings; real art; placeholder prices.
- 2026-09-27 cleanup: removed every superseded spec + screenshot from the package (old HUD grid 01–05, old Customize 26–30/89, old Promotions 56/70/71/79); re-captured 72–77, 80, 81, 88, 90, 91; merged Part I layout/lock rules into A1, A5, E1, E4, G1, G2, DATA §5/§8/§10 so each topic has one current spec.

- 2026-09-28 · `icon_sheet_update_2026-09-28/` (scoped: icons; complete, replaces all earlier icon notes). New atlas `merc-manager_ICON-COLLECTION.png` replaces `icon_atlas_1x_16px_grid.png`. Every prototype icon moved to atlas ids (`merc-icons.js`); all icons ×1+ integer scale (windows no longer scaled ×0.86/×0.72; tree icons ×1.5 → ×2). Stars on green→red gradient; face outline row; close = small X; Failed = large X. Baseline for icons: that package's `reference_html/`.
- 2026-09-28 (update) · Windows no longer cover the bottom bar (1280×644 in HUD; layouts shrink to fit, checked on every tab). Sigils re-aligned in the atlas (user edit) and now read from the atlas.
- 2026-09-28 (final) · Guide finalized: window-layout section (Merc portrait 196×196 + scroll details, Legal permit card, compact Investments trade controls), sigil re-alignment, refreshed Merc Viewer / Investments screenshots.
- 2026-09-28 (final 2) · All star ratings on star_set/star_unused; prototype icons render as single images; full screenshot set (43) incl. HUD windows, Contract results, Legal dialogs, Customize.
