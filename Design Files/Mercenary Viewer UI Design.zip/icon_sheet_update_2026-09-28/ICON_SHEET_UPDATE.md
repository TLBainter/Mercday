# Icon sheet update · 2026-09-28

**For the implementer.** Complete guide for moving the Godot UI to the new icon atlas. It replaces the old atlas `icon_atlas_1x_16px_grid.png` and its `ICON_INDEX.md` / `icon_index.json` entirely. Nothing from earlier icon notes applies.

## What this update covers

1. **New atlas** replaces every icon in the UI (hand-drawn maps, CSS shapes, font glyphs). See “Where each icon goes” and the id table.
2. **Pixel-art rules**: icons never below ×1, integer scales only, nearest filtering, tint modes, active-tab two-tone.
3. **Window layout**: windows at 1:1, never over the bottom bar; layout changes that made them fit.
4. **Behavior changes**: contract status marks, skull vs bars, one magnifier, four trend arrows, mood faces, face outlines.
5. **Stars**: one star art for every rating (difficulty and positive), green → red gradient.

## Package

| File | What it is |
|---|---|
| `merc-manager_ICON-COLLECTION.png` | The atlas. 256×640, 16 cols × 40 rows of 16×16 cells, transparent, 1 px per art pixel. **Source of truth.** |
| `icon_ids.json` | Every icon: id, cell, trimmed offset + size in the cell, tint mode, where it is used, what it replaces. |
| `icon_reference_5x_ids.png` | The atlas at 5× with id and cell under each icon. |
| `merc-icons.js` | Prototype atlas reader (same ids). Reference for the tint rules. |
| `screenshots/` | Every screen, tab and popup after the change, numbered in reading order. |
| `reference_html/` | The prototype (open any `.dc.html` in a browser). Reference only. Each icon renders as one image (SVG from the atlas pixels), not one HTML box per pixel. |

## Hard rules

1. **Never below native size.** Every icon draws at an integer scale **×1 or larger** (1 art pixel = N whole screen pixels). No ×0.86, no ×1.5, no shrinking a window or container that holds icons. If a window does not fit, change its layout, not its scale. The prototype had windows scaled ×0.86/×0.72 and some tree icons at ×1.5; all are now integer (see “Window layout”).
2. **Nearest filtering.** `texture_filter = NEAREST` on every icon. Snap icon positions to whole pixels.
3. **One atlas, cut by cell.** One `AtlasTexture` per id, `region = Rect2(col*16, row*16, 16, 16)`. Use the trimmed `offset`/`size` from `icon_ids.json` only where a tight box is needed (currency glyph, skull, star9).
4. **Tint modes** (`tint` in `icon_ids.json`):
   - **mono**: white/gray art. `modulate` with the screen's color. Multiplication keeps gray shading and black outlines.
   - **color**: draw as-is.
   - **Grayscale + modulate**: some color icons are re-colored by meaning (trend arrows, difficulty stars, customize-tree Base logo, Accept/Reject). Use a small grayscale shader, then modulate.
5. **Active orange tab**: two-tone icon. Light neutral pixels → `#5a3510`, mid grays → `#3a2008`, saturated pixels and outlines → `#0a0f1c`. Shader on the active tab's `TextureRect`, or pre-baked `_on` variants. (Grayscale-multiply merged Job Ads' orange rays into its body.)
6. **Faces**: row 7 filled, row 8 outline (same order). Current value = filled, modulated with its level color. Every other face = its outline twin (`<id>_o`), modulated `#2b4f8a`.
7. **Retire** every hand-coded pixel map, the flipped trend arrow, the CSS prison bars and the font “X”.

### Autoload

```gdscript
# icons.gd (autoload "Icons")
const ATLAS := preload("res://ui/icons/merc-manager_ICON-COLLECTION.png")
static var _cache := {}
static var CELLS := {}   # id -> Vector2i(col, row)
static var OFFSETS := {} # id -> Vector2i trimmed offset
static var SIZES := {}   # id -> Vector2i trimmed size

static func _static_init() -> void:
	var j = JSON.parse_string(FileAccess.get_file_as_string("res://ui/icons/icon_ids.json"))
	for ic in j.icons:
		CELLS[ic.id] = Vector2i(ic.cell[0], ic.cell[1])
		OFFSETS[ic.id] = Vector2i(ic.offset[0], ic.offset[1])
		SIZES[ic.id] = Vector2i(ic.size[0], ic.size[1])

static func tex(id: String, trimmed := false) -> AtlasTexture:
	var key := id + ("|t" if trimmed else "")
	if _cache.has(key): return _cache[key]
	var c: Vector2i = CELLS[id]
	var t := AtlasTexture.new()
	t.atlas = ATLAS
	t.region = Rect2(c.x * 16, c.y * 16, 16, 16)
	if trimmed: # tight box from icon_ids.json (currency glyph, skull, star9)
		var o: Vector2i = OFFSETS[id]; var s: Vector2i = SIZES[id]
		t.region = Rect2(c.x * 16 + o.x, c.y * 16 + o.y, s.x, s.y)
	_cache[key] = t
	return t
```

Set `TextureRect.stretch_mode = STRETCH_KEEP_CENTERED` or an explicit integer `scale`; never `STRETCH_SCALE` on a non-multiple of 16.

## Window layout (needed for rule 1)

- **1:1 always.** Windows used to be scaled ×0.86 (HUD windows, Client / Finance sub-windows, Contract Viewer's merc popup) and ×0.72 (Hiring's merc popup), which shrank 16 px sigils to 11–14 px. All scaling is removed.
- **Never cover the bottom bar** (bank, date, time, speed buttons; 76 px tall). Windows opened from the HUD are **1280×644** and fill the area above the bar. Everything else on screen may be covered.
- **Window height is a parameter.** Each window scene takes `frame_h` (default 720 when opened alone, 644 from the HUD) and its layout fills that height (root rows `minmax(0,1fr)`, long lists scroll). Popups opened inside a window inherit its height and stay inside it: merc popup 988 wide, Client / Finance sub-windows 940 wide, Dispatch 1280 wide.
- **Close X** sits inside the frame at top 10 / right 10 (it used to hang off the corner and went off-screen at 1:1).
- **What changed to fit 644** (all measured on every tab; nothing else overflows):
  - **Merc Viewer:** portrait stays a **196×196 square**; middle column 208 → 228 px wide. Under the name, Heritage / Primary Ancestry / Secondary Ancestry / Age / Criminality are one scroll area with 4 px gaps (was separate boxes with 8–14 px gaps). Monthly Salary is pinned at the bottom of the column. Metrics tab embed 596 → 520 px tall (chart 466 → 390).
  - **Metrics Viewer:** chart 550 → 474 px tall.
  - **Legal › Permits location card:** 84 px image on the left; name, nation, “Average Difficulty” label and stars right-aligned beside it, all above the divider. The numeric difficulty value is removed (the stars show it). Request button stays inside the card.
  - **Finance › Investments trade panel:** Buy/Sell switch 34 → 28 px tall, quantity stepper 38 → 28 px (compact variant, with Max), each on its own full-width row. “Quantity (shares)” heading removed (kept as tooltip). Panel gaps stay 12 px.
  - **Finance › Hiring:** fixed min-height removed so the panel fits.
  - **Customize tier dialog:** position clamped so the 400 px dialog stays inside the window.
  - **Legal review dialog:** 680 → 740 px wide, right column 250 → 310 px so the 11-face Relationship row fits.

## Behavior changes

- **Contract status**: Completed (Success) = `check_lg`; Completed (Failed) = `x_lg` (not the skull); Rejected = `thumbs_down`; Expired = `prohibited`; unclaimed results = `alert` (no spoiler).
- **Skull** is only the Deceased overlay on a merc portrait. **Bars** = Captured overlay (contract results and Legal › Bail).
- **One magnifier** (`magnifier`) for every magnifier: Background Check node and Bazaar search.
- **Trend arrows**: four icons (`trend_up`, `trend_diag_up`, `trend_diag_down`, `trend_down`). No flip. Color = good/bad/neutral (green/red/blue).
- **Merc Mood** uses the opinion faces: Angry −5, Frustrated −3, Neutral ±0, Okay +3, Happy +5.
- **Plans**: `sun_low` / `sun_rising` / `sun_full` = Free / Pro / Enterprise (wherever a plan shows an icon).
- **Metrics category** and **Rapid Survey** share `chart_arrow`. Merc Viewer Metrics tab shares the HUD `metrics` icon.
- **Caret left**: left arrow of horizontal scrollbars only. **Thumbs up**: reserved, unused.

## Stars

- **All stars**: `star_set` (0,13) for set stars, `star_unused` (1,13) for unused, full 16×16 cell. Half star = left 8 columns of `star_set` + right 8 of `star_unused`. ×1 in lists, tooltips and notifications; ×2 on the contract detail header and Legal › Average Difficulty.
- **Rating stars** (Contract Match, applicant Fit, crew/merc skills and traits, success rate) use the **same** `star_set` / `star_unused` art as difficulty (outline + shading), full 16×16 cell at ×1 (×2 where the old star was 27 px). `star9` is no longer used anywhere (its cell also has 4 stray pixels at y=15).
- **Color**: the whole row is modulated with one color picked by the row's value, on a green → red gradient (grayscale first; `star_unused` has two gold pixels):
  - Difficulty (higher = harder): 0.5: '#29e029', 1: '#50e029', 1.5: '#77e029', 2: '#a6e33b', 2.5: '#cae33b', 3: '#e3d83b', 3.5: '#e3b43b', 4: '#e08629', 4.5: '#e05f29', 5: '#e03829'
  - Positive ratings: the same list reversed (0.5 = red, 5 = bright green).
  - Godot: a `Gradient` with these 10 stops, sampled at `(value - 0.5) / 4.5` (inverted for ratings).
  - Unused color: `#1f3560` (`#2b4f8a` on Client Viewer).

## Where each icon goes, and size changes

| Screen | Icons | Size / fit |
|---|---|---|
| Game HUD | Menu 1–9: `mercs` `contracts` `clients` `promotions` `mercday` `finance` `legal` `bazaar` `metrics` (row 0) | Full cell ×4 (64 px). My Finance uses its own 16×16 art (was the 7×9 currency glyph scaled ×7). |
| Game HUD | `bell` (9,0), `gear` (10,0) | ×2. Bell full color; when the notification panel is open, bell uses the active-tab two-tone. Gear modulated with the button state color. |
| Game HUD › notifications | `alert` (results ready), `trend_up` / `trend_down` (stock), `check_sm`, `dot`, difficulty stars | Alert full cell ×2. Trend arrows are separate art, no flip. Stars: see Stars. |
| All windows | Close button → `x_sm` (2,2) | Trimmed 10×10 ×3 (30 px) on windows/dialogs, ×1 on 18 px mini closes. 1-art-px dark outline. (The large X at ×4 overflowed the frame.) |
| Merc Viewer | Tabs: `eye` `tree` `arrow_up_green` `arrow_down_red` `backpack` `smiley` `fist` `metrics` | Full cell ×2 (Tab Button detects 256 cells → 16 cols). |
| Merc Viewer › Coaching | PIP modes → `pip_*` (9..15,3 and 9..15,4); Coach button → `whistle` (7,3) | PIPs: centered 8×8 of the cell ×3; locked PIP = flat `#3b4d6e` silhouette. Whistle 14×16 ×2. |
| Merc Viewer / Finance › mood & relationships | Faces row 7 (filled) + row 8 (outline) | Current value = filled face modulated with its level color; other faces = their own outline twin modulated `#2b4f8a`. 12×12 art: ×2 in rows (24 px), ×4 large (48 px), ×3 medium (36 px). |
| Merc cards (Contract, Dispatch, Finance, Hiring, Legal) | Tradition sigils (row 14) | Full cell ×1 in 18–20 px frames; ×4 in the 70 px Finance/Merc feature frame; ×2 in Merc Viewer header. Never below ×1. Sigil art was re-aligned in the atlas (it sat 1 px high); always use the full 16×16 cell so the alignment holds. |
| Contract Viewer › status | Completed (Success) `check_lg`; Completed (Failed) `x_lg`; Rejected `thumbs_down`; Expired `prohibited`; unclaimed results `alert` | Full cell: list ×2 (32 px), detail header ×5 (80 px). Failed is no longer the skull. |
| Contract Viewer › Accept / Reject | `check_lg` / `x_lg` | Solid white + 1-art-px black outline, ×3. |
| Contract Viewer › crew slots | Required `person` mod `#f28c28`; optional `person` mod `#f3ead7`; unavailable `person_outline` mod `#3b6fb6` | 14×14 ×2. |
| Contract results | Deceased `skull` (8,2); Captured `bars` (9,2) | Skull trimmed 11×13 ×3, **centered** on the 48 px portrait. Bars full cell ×3. |
| Legal | Tabs `permit` `coin` `bail_bars`; permit on/off `check_sm` / `x_sm`; confirm `check_sm` | Tabs full cell ×2. Status icons 12×12 window ×2. |
| Legal › Bail | Captured merc portrait → `bars` (9,2) | Full cell ×3 centered in the 56 px portrait (was 4 CSS bars). |
| Client Viewer | Tabs `person` `house` `building`; `scroll` (13,9→10); Avg Difficulty stars | Tabs full cell ×2. Avg Difficulty uses the difficulty gradient. |
| Finance Viewer | Tabs `eye` `money_bag` `add_person` `invest` `piggy`; trend arrows | Tabs ×2. Arrows: 9×8 window, grayscale + modulate good/bad/neutral (green/red/blue). |
| Metrics Viewer | Tabs `guild_banner` `contracts` `mercs`; trend arrows | As Finance. |
| Promotions | Campaign types `wom` `flyers` `direct_sale` `radio` `sponsorship`; tabs `job_ads` `guild_ads` `add_person` | Campaign cards / type picker full cell ×2 (32 px). Tabs ×2. |
| Hiring | View applicant `eye` | 12×8 ×1, full color. |
| Bazaar | Tabs `shop` `cart` `parcel`; search → `magnifier` | Tabs ×2. Magnifier 14×14 ×2 mod `#0a0f1c` (28 px in the 44 px button). |
| Subscription › Plans | Plans tab + header logo `mercday`; Customize tab `customize`; feature check `check_sm` | Logo ×2. Check 12×12 window ×1. |
| Subscription › Customize tree | Every category/node → rows 9–12 (see id table) | White art modulated with the tier / category progress color. Node ×3 (48 px), tooltip ×2, category tabs / tier list / next-tier icons ×2 (were ×1.5, now integer; tier-list box 34 → 38 px). |
| Everywhere | Currency `note` (14,2) | Trimmed 5×9 at the text size (×1 or ×2). |
| Everywhere | `lock` (15,2) | 8×9, modulated (keyhole shading survives). ×3 on tabs, ×6 on locked pages / feature locks. |

Not yet swapped in the prototype (CSS/text stand-ins). **Use the atlas in engine**: speed buttons `speed_*`, dropdown/sort carets `caret_*`, `filter`, `plus` / `minus`, Bazaar clear-search `x_sm`. Tradition sigils now come from atlas row 14 everywhere (the prototype's `sigils.js` maps are only a fallback).

Animation note: Customize-tree purchase “pop” scales a node to ×1.04–×1.3 for a few frames. That only ever goes above native; in engine, step it in whole-pixel sizes or keep it.

## Full id table

Cell = (col,row). Size @ offset = trimmed art inside the cell.

### HUD & controls

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `mercs` | 0,0 | 16×14 @ 0,1 | color | Game HUD menu 1 · My Mercs; Metrics Viewer › Merc tab | My Mercs (0,0); Metrics · Merc (2,4) |
| `contracts` | 1,0 | 13×13 @ 2,2 | color | Game HUD menu 2 · My Contracts; Metrics Viewer › Contract tab | My Contracts (1,0); Metrics · Contract (1,4) |
| `clients` | 2,0 | 14×11 @ 1,4 | color | Game HUD menu 3 · My Clients | My Clients (2,0) |
| `promotions` | 3,0 | 15×12 @ 1,2 | color | Game HUD menu 4 · My Promotions | My Promotions (3,0) |
| `mercday` | 4,0 | 14×14 @ 1,1 | color | Game HUD menu 5 · My Mercday; Customize tree › Base Plan node and Mercday branding | My Mercday (4,0); Mercday logo (0,11) |
| `finance` | 5,0 | 11×14 @ 3,1 | color | Game HUD menu 6 · My Finance (replaces the scaled-up Note glyph) | My Finance (5,0) |
| `legal` | 6,0 | 14×13 @ 2,2 | color | Game HUD menu 7 · My Legal | My Legal (6,0) |
| `bazaar` | 7,0 | 14×14 @ 1,1 | color | Game HUD menu 8 · My Bazaar | My Bazaar (7,0) |
| `metrics` | 8,0 | 14×14 @ 1,1 | color | Game HUD menu 9 · My Metrics; Merc Viewer › Metrics tab | My Metrics (8,0); Merc · Metrics (7,3) |
| `bell` | 9,0 | 16×15 @ 0,0 | color | Game HUD top bar | Notification bell (0,1) |
| `gear` | 10,0 | 16×16 @ 0,0 | mono | Game HUD top bar | Settings gear (1,1) |
| `dot` | 11,0 | 8×8 @ 4,4 | mono | Notification Dot (tinted) | Notification dot (0,32) |
| `ring8` | 12,0 | 8×8 @ 4,4 | mono | Notification Dot pulse frame | Pulse ring 8 (1,32) |
| `ring10` | 13,0 | 10×10 @ 3,3 | mono | Notification Dot pulse frame | Pulse ring 10 (2,32) |
| `ring12` | 14,0 | 12×12 @ 2,2 | mono | Notification Dot pulse frame | Pulse ring 12 (3,32) |
| `ring14` | 15,0 | 14×14 @ 1,1 | mono | Notification Dot pulse frame | Pulse ring 14 (4,32) |
| `speed_slow` | 0,1 | 8×7 @ 4,4 | mono | Game HUD bottom bar | Speed · Slow Down (2,1) |
| `pause` | 1,1 | 5×7 @ 5,4 | mono | Game HUD bottom bar | Speed · Pause (3,1) |
| `play` | 2,1 | 4×7 @ 6,4 | mono | Game HUD bottom bar | Speed · Play (4,1) |
| `speed_fast` | 3,1 | 8×7 @ 4,4 | mono | Game HUD bottom bar | Speed · Fast Forward (5,1) |
| `speed_faster` | 4,1 | 12×7 @ 2,4 | mono | Game HUD bottom bar | Speed · Faster (6,1) |
| `caret_down` | 5,1 | 5×3 @ 5,6 | mono | All dropdowns; sort toggle descending (orange tint); filter group collapse ▼ | Dropdown caret (0,37); Sort descending (2,37); Group collapse ▼ (5,37) |
| `caret_up` | 6,1 | 5×3 @ 5,6 | mono | Sort toggle ascending (blue tint) | Sort ascending (1,37) |
| `caret_right` | 7,1 | 3×5 @ 7,5 | mono | Filter group expand ▶ (Promotions, Hiring) | Group expand ▶ (4,37) |
| `caret_left` | 8,1 | 3×5 @ 6,5 | mono | Left scroll arrow on horizontal scrollbars (only use) (New. No old equivalent.) | new |
| `filter` | 9,1 | 5×5 @ 5,5 | mono | All filter buttons | Filter (3,37) |
| `plus` | 10,1 | 5×5 @ 6,5 | mono | Quantity Stepper; New Campaign; Request a Loan | Plus (0,38) |
| `minus` | 11,1 | 5×1 @ 6,7 | mono | Quantity Stepper | Minus (1,38) |
| `trend_up` | 12,1 | 7×8 @ 4,4 | color | Finance Viewer trends | Arrow up (0,33) |
| `trend_diag_up` | 13,1 | 8×8 @ 3,4 | color | Finance Viewer trends | Arrow diagonal (1,33) |
| `trend_diag_down` | 14,1 | 8×8 @ 3,4 | color | Finance Viewer trends (was a runtime flip of the diagonal) | Arrow diagonal (1,33) |
| `trend_down` | 15,1 | 7×8 @ 4,4 | color | Finance Viewer trends (was a runtime flip of Arrow up) | Arrow up (0,33) |

### Status & feedback

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `x_lg` | 0,2 | 12×12 @ 2,2 | color | Window close on all windows; Contract Viewer X; Contract Viewer › status Completed (Failed) (Replaces the skull as the claimed-Failed contract mark.) | Window close (0,2); X 10×10 (3,30); Failed (skull) (1,39) |
| `check_lg` | 1,2 | 13×10 @ 2,2 | color | Contract Viewer › status Completed (Success) | Status · Completed (0,29) |
| `x_sm` | 2,2 | 10×10 @ 3,3 | color | Legal X; Subscription Viewer feature X | X 9×9 (4,30); X 7×7 (5,30) |
| `check_sm` | 3,2 | 11×10 @ 3,3 | color | Legal check + confirm; Subscription Viewer feature check | Check 9×9 (0,30); Check 9×9 (confirm) (1,30); Check 7×7 (2,30) |
| `alert` | 4,2 | 4×10 @ 6,3 | color | Legal alerts; unclaimed Completed/Failed contract mark (Contract Viewer, HUD notifications) | Alert (!) (6,30); Results ready “!” (0,39) |
| `thumbs_down` | 5,2 | 15×16 @ 0,0 | color | Contract Viewer › status Rejected | Status · Rejected (1,29) |
| `thumbs_up` | 6,2 | 15×16 @ 1,0 | color | Not used yet (Reserved. No use yet.) | new |
| `prohibited` | 7,2 | 16×16 @ 0,0 | color | Contract Viewer › status Expired | Status · Expired (2,29) |
| `skull` | 8,2 | 11×13 @ 3,2 | color | Contract results › Deceased overlay on merc portrait (only use) | Deceased overlay (2,39) |
| `bars` | 9,2 | 16×16 @ 0,0 | color | Contract results › Captured overlay | Captured overlay (3,39) |
| `note` | 14,2 | 5×9 @ 5,3 | mono | Every money amount (now 5×9, was 7×9) | Note (currency) (0,34) |
| `lock` | 15,2 | 8×9 @ 4,3 | mono | Feature Lock; locked tabs | Lock (0,31) |

### Merc Viewer tabs, coaching

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `eye` | 0,3 | 12×8 @ 2,4 | color | Merc Viewer › Overview tab; Finance › Overview tab; Promotions › View applicant | Merc · Overview (0,3); Finance · Overview (0,6); View applicant (eye) (1,28) |
| `tree` | 1,3 | 12×13 @ 2,2 | color | Merc Viewer › Skills tab | Merc · Skills (1,3) |
| `arrow_up_green` | 2,3 | 12×14 @ 2,1 | color | Merc Viewer › Perks tab | Merc · Perks (2,3) |
| `arrow_down_red` | 3,3 | 12×14 @ 2,1 | color | Merc Viewer › Drawbacks tab | Merc · Drawbacks (3,3) |
| `backpack` | 4,3 | 14×13 @ 1,2 | color | Merc Viewer › Equipment tab | Merc · Equipment (4,3) |
| `smiley` | 5,3 | 12×12 @ 2,2 | color | Merc Viewer › Relationships tab | Merc · Relationships (5,3) |
| `fist` | 6,3 | 14×15 @ 1,0 | color | Merc Viewer › Actions tab | Merc · Actions (6,3) |
| `whistle` | 7,3 | 14×16 @ 1,0 | color | Merc Viewer › Coach button | Coach whistle (0,26) |
| `guild_banner` | 8,3 | 10×13 @ 3,2 | color | Metrics Viewer › Guild tab | Metrics · Guild (0,4) |
| `pip_auto` | 9,3 | 8×8 @ 4,4 | color | Merc Viewer › Standard PIP | PIP · Auto (0,23) |
| `pip_random` | 10,3 | 8×8 @ 4,4 | color | Merc Viewer › Standard PIP | PIP · Random (1,23) |
| `pip_utility` | 11,3 | 8×8 @ 4,4 | color | Merc Viewer › Standard PIP | PIP · Utility (2,23) |
| `pip_stats` | 12,3 | 8×8 @ 4,4 | color | Merc Viewer › Standard PIP | PIP · Stats (3,23) |
| `pip_support` | 13,3 | 8×8 @ 4,4 | color | Merc Viewer › Combat PIP | PIP · Support (0,24) |
| `pip_defensive` | 14,3 | 8×8 @ 4,4 | color | Merc Viewer › Combat PIP | PIP · Defensive (1,24) |
| `pip_offensive` | 15,3 | 8×8 @ 4,4 | color | Merc Viewer › Combat PIP | PIP · Offensive (2,24) |

### Clients, campaign types, skill PIPs

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `person_outline` | 0,4 | 14×14 @ 1,1 | mono | Contract Viewer › crew slot unavailable | Crew slot · unavailable (3,35) |
| `person` | 1,4 | 14×14 @ 1,1 | mono | Client Viewer › People tab; Contract Viewer › crew slot required / optional (tinted) | Client · People (0,5); Crew slot · required (1,35); Crew slot · optional (2,35) |
| `house` | 2,4 | 14×14 @ 1,1 | mono | Client Viewer › Places tab | Client · Places (1,5) |
| `building` | 3,4 | 14×14 @ 1,1 | mono | Client Viewer › Orgs tab | Client · Orgs (2,5) |
| `wom` | 4,4 | 12×8 @ 2,4 | color | Promotions › campaign type | Word of Mouth (0,27) |
| `flyers` | 5,4 | 8×10 @ 4,3 | color | Promotions › campaign type | Flyers (1,27) |
| `direct_sale` | 6,4 | 10×11 @ 3,2 | color | Promotions › campaign type | Direct Sale (2,27) |
| `radio` | 7,4 | 10×10 @ 3,3 | color | Promotions › campaign type | Radio (3,27) |
| `sponsorship` | 8,4 | 10×10 @ 3,3 | color | Promotions › campaign type | Sponsorship (4,27) |
| `pip_skills` | 9,4 | 6×7 @ 5,4 | color | Merc Viewer › Skill PIP | PIP · Skills (0,25) |
| `pip_existing` | 10,4 | 7×7 @ 4,4 | color | Merc Viewer › Skill PIP | PIP · Existing Skills (1,25) |
| `pip_new` | 11,4 | 6×7 @ 5,4 | color | Merc Viewer › Skill PIP | PIP · New Skills (2,25) |
| `pip_universal` | 12,4 | 8×8 @ 4,4 | color | Merc Viewer › Skill PIP | PIP · Universal (3,25) |
| `pip_ancestral` | 13,4 | 6×8 @ 5,4 | color | Merc Viewer › Skill PIP | PIP · Ancestral (4,25) |
| `pip_tradition` | 14,4 | 8×8 @ 4,4 | color | Merc Viewer › Skill PIP | PIP · Tradition (5,25) |
| `pip_spell` | 15,4 | 8×8 @ 4,4 | color | Merc Viewer › Skill PIP | PIP · Spell (6,25) |

### Finance, Mercday, Bazaar, Legal, Promotions tabs

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `money_bag` | 0,5 | 14×14 @ 1,1 | color | Finance › Payroll tab | Finance · Payroll (1,6) |
| `add_person` | 1,5 | 13×11 @ 3,4 | color | Finance › Hiring tab; Promotions › Applicants | Finance · Hiring (2,6); Applicants (orange) (0,28) |
| `invest` | 2,5 | 13×10 @ 2,4 | color | Finance › Invest tab | Finance · Invest (3,6) |
| `piggy` | 3,5 | 15×12 @ 0,3 | color | Finance › Loans tab | Finance · Loans (4,6) |
| `sun_low` | 4,5 | 14×6 @ 1,10 | color | Mercday › Free plan | Free plan (0,7) |
| `sun_rising` | 5,5 | 16×11 @ 0,5 | color | Mercday › Pro plan | Pro plan (1,7) |
| `sun_full` | 6,5 | 16×16 @ 0,0 | color | Mercday › Enterprise plan | Enterprise plan (2,7) |
| `customize` | 7,5 | 10×10 @ 3,3 | color | Mercday › Customize tab | Customize (3,7) |
| `shop` | 8,5 | 14×15 @ 1,1 | color | Bazaar › Shop tab | Bazaar · Shop (0,8) |
| `cart` | 9,5 | 16×14 @ 0,1 | color | Bazaar › Cart tab | Bazaar · Cart (1,8) |
| `parcel` | 10,5 | 14×12 @ 1,2 | color | Bazaar › Orders tab | Bazaar · Orders (2,8) |
| `permit` | 11,5 | 14×15 @ 1,1 | color | Legal › Permits tab | Legal · Permits (0,9) |
| `coin` | 12,5 | 14×14 @ 1,1 | color | Legal › Fines tab | Legal · Fines (1,9) |
| `bail_bars` | 13,5 | 12×14 @ 2,1 | color | Legal › Bailout tab | Legal · Bailout (2,9) |
| `job_ads` | 14,5 | 14×15 @ 2,0 | color | Promotions › Job Ads tab | Job Ads (0,10) |
| `guild_ads` | 15,5 | 14×15 @ 1,1 | color | Promotions › Guild Ads tab | Guild Ads (1,10) |

### Opinion faces (row 7 filled, row 8 outline)

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `face_unselected` | 0,7 | 12×12 @ 2,2 | mono | Spare neutral face (filled) | new |
| `face_m5` | 1,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship; Merc Mood · Angry (White, tinted in engine. Mood mapping: Angry −5, Frustrated −3, Neutral ±0, Okay +3, Happy +5.) | −5 (0,20); Mood · Angry (0,21) |
| `face_m4` | 2,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship | −4 (1,20) |
| `face_m3` | 3,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship; Merc Mood · Frustrated | −3 (2,20); Mood · Frustrated (1,21) |
| `face_m2` | 4,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship | −2 (3,20) |
| `face_m1` | 5,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship | −1 (4,20) |
| `face_0` | 6,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship; Merc Mood · Neutral | ±0 Neutral (5,20); Mood · Neutral (2,21) |
| `face_p1` | 7,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship | +1 (6,20) |
| `face_p2` | 8,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship | +2 (7,20) |
| `face_p3` | 9,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship; Merc Mood · Okay | +3 (8,20); Mood · Okay (3,21) |
| `face_p4` | 10,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship | +4 (9,20) |
| `face_p5` | 11,7 | 12×12 @ 2,2 | mono | Guild Opinion / Relationship; Merc Mood · Happy | +5 (10,20); Mood · Happy (4,21) |
| `face_unselected_o` | 0,8 | 12×12 @ 2,2 | mono | Spare neutral face (outline) | new |
| `face_m5_o` | 1,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) (Replaces the single generic unselected face: each unselected face now keeps its own expression.) | Face · unselected (0,22) |
| `face_m4_o` | 2,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_m3_o` | 3,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_m2_o` | 4,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_m1_o` | 5,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_0_o` | 6,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_p1_o` | 7,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_p2_o` | 8,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_p3_o` | 9,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_p4_o` | 10,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |
| `face_p5_o` | 11,8 | 12×12 @ 2,2 | mono | Every opinion / relationship / mood scale: the faces that are not the current value (tinted #2b4f8a) | new |

### Customize upgrade tree

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `base_plan` | 0,9 | 8×8 @ 4,4 | mono | Customize tree › Base Plan | Base Plan (alt) (1,11) |
| `limits` | 2,9 | 12×14 @ 2,1 | mono | Customize tree › Limits (category) | Limits (category) (0,12) |
| `seats` | 3,9 | 12×11 @ 2,2 | mono | Customize tree › Seats | Seats (1,12) |
| `limit_contracts` | 4,9 | 9×10 @ 4,2 | mono | Customize tree › Contracts (limit) | Contracts (limit) (2,12) |
| `insights` | 5,9 | 12×8 @ 2,4 | mono | Customize tree › Insights (category) | Insights (category) (0,15) |
| `coaching` | 7,9 | 10×15 @ 3,0 | mono | Customize tree › Coaching (category) | Coaching (category) (0,13) |
| `pip_plan` | 8,9 | 10×11 @ 3,2 | mono | Customize tree › Performance Improvement Plan | Perf. Improvement Plan (1,13) |
| `combat_pip` | 9,9 | 12×12 @ 2,2 | mono | Customize tree › Combat PIP | Combat PIP (2,13) |
| `skill_pip` | 10,9 | 14×14 @ 1,1 | mono | Customize tree › Skill PIP | Skill PIP (3,13) |
| `magic_pip` | 11,9 | 14×13 @ 1,1 | mono | Customize tree › Magic PIP | Magic PIP (4,13) |
| `testing` | 0,10 | 12×11 @ 2,2 | mono | Customize tree › Testing (category) | Testing (category) (0,14) |
| `aptitude` | 1,10 | 12×14 @ 2,1 | mono | Customize tree › Aptitude Test | Aptitude Test (1,14) |
| `brawn` | 2,10 | 12×14 @ 2,1 | mono | Customize tree › Brawn Test | Brawn Test (2,14) |
| `readiness` | 3,10 | 8×13 @ 4,2 | mono | Customize tree › Readiness Test | Readiness Test (3,14) |
| `personality` | 4,10 | 12×12 @ 2,2 | mono | Customize tree › Personality Test | Personality Test (4,14) |
| `skill_test` | 5,10 | 12×11 @ 2,2 | mono | Customize tree › Skill Test | Skill Test (5,14) |
| `education` | 6,10 | 12×9 @ 2,3 | mono | Customize tree › Education Exam | Education Exam (6,14) |
| `less_legal` | 8,10 | 12×8 @ 2,5 | mono | Customize tree › Less Legal (category) | Less Legal (category) (0,16) |
| `discrimination` | 9,10 | 14×14 @ 1,1 | mono | Customize tree › Discrimination | Discrimination (1,16) |
| `odd_jobs` | 10,10 | 14×14 @ 1,1 | mono | Customize tree › Odd Jobs | Odd Jobs (2,16) |
| `who_knows` | 11,10 | 14×15 @ 1,1 | mono | Customize tree › Who Knows a Guy | Who Knows a Guy (3,16) |
| `scroll` | 13,10 | 12×14 @ 2,1 | mono | Client Viewer › scroll | Scroll (0,36) |
| `magnifier` | 0,11 | 14×14 @ 1,1 | mono | Every magnifier: Customize tree › Background Check; Bazaar › search field and search button (One magnifier for all uses.) | Background Check (1,15); Search (1,36) |
| `criminal` | 1,11 | 12×14 @ 2,1 | mono | Customize tree › Criminal Background Check | Criminal Bkg Check (2,15) |
| `survey` | 2,11 | 10×11 @ 3,2 | mono | Customize tree › Employee Survey | Employee Survey (3,15) |
| `peer` | 3,11 | 12×11 @ 2,2 | mono | Customize tree › Peer Review | Peer Review (4,15) |
| `customer` | 4,11 | 12×11 @ 2,2 | mono | Customize tree › Customer Satisfaction | Customer Satisfaction (5,15) |
| `chart_arrow` | 5,11 | 14×14 @ 1,1 | mono | Customize tree › Rapid Survey; Customize tree › Metrics (category) | Rapid Survey (6,15); Metrics (old category) (9,15) |
| `contract_metrics` | 6,11 | 10×9 @ 3,3 | mono | Customize tree › Contract Metrics | Contract Metrics (7,15) |
| `merc_metrics` | 7,11 | 12×13 @ 2,1 | mono | Customize tree › Merc Metrics | Merc Metrics (8,15) |
| `bazaar_cat` | 9,11 | 14×14 @ 1,1 | mono | Customize tree › Bazaar (category) | Bazaar (category) (0,18) |
| `bazaar_node` | 10,11 | 14×12 @ 1,2 | mono | Customize tree › Bazaar | Bazaar (1,18) |
| `better_items` | 11,11 | 16×14 @ 0,1 | mono | Customize tree › Better Items | Better Items (2,18) |
| `faster_items` | 12,11 | 12×7 @ 2,5 | mono | Customize tree › Faster Items | Faster Items (3,18) |
| `legal_cat` | 0,12 | 14×12 @ 1,2 | mono | Customize tree › Legal (category) (Redrawn (was a lamp).) | Legal (category) (0,17) |
| `ops_permit` | 1,12 | 9×10 @ 3,3 | mono | Customize tree › Operations Permits | Operations Permits (1,17) |
| `teleport` | 2,12 | 12×12 @ 2,2 | mono | Customize tree › Teleportation Permit (Redrawn (was a target).) | Teleportation Permit (2,17) |
| `representation` | 3,12 | 14×12 @ 1,2 | mono | Customize tree › Representation | Representation (3,17) |
| `counsel` | 4,12 | 14×11 @ 1,2 | mono | Customize tree › Advisory Counsel | Advisory Counsel (4,17) |
| `promo_cat` | 6,12 | 14×15 @ 1,0 | mono | Customize tree › Promotions (category) (Updated to a cleaner outline.) | Promotions (category) (0,19) |
| `promo_node` | 7,12 | 8×10 @ 4,3 | mono | Customize tree › Promotions | Promotions (1,19) |
| `promo_methods` | 8,12 | 10×15 @ 3,0 | mono | Customize tree › Promo Methods | Promo Methods (2,19) |
| `long_promos` | 9,12 | 10×12 @ 3,2 | mono | Customize tree › Long Promos | Long Promos (3,19) |
| `guild_promo` | 10,12 | 12×13 @ 3,2 | mono | Customize tree › Guild Promo (Redrawn: the Guild tab banner with a plus (was a shield).) | Guild Promo (5,19) |
| `marketing` | 11,12 | 14×15 @ 1,1 | mono | Customize tree › Marketing Agency | Marketing Agency (4,19) |

### Stars

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `star_set` | 0,13 | 16×16 @ 0,0 | mono | Difficulty stars that are set: Contract Viewer (list, tooltip, detail, results), HUD notifications, Legal (Average Difficulty, review), Client Viewer avg difficulty | Star 9×9 (1,34) |
| `star_unused` | 1,13 | 14×15 @ 1,1 | color | Difficulty stars that are unused (same places); half star = left 8 columns of 0,13 + right 8 of 1,13 | Star 9×9 (1,34) |
| `star9` | 2,13 | 9×9 @ 3,3 | color | Not used (all ratings use `star_set` / `star_unused`) | Star 9×9 (1,34) |
| `star7` | 3,13 | 14×12 @ 1,4 | color | Not used after the difficulty change (Client Viewer avg difficulty moved to the large stars) | Star 7×7 (2,34) |

### Tradition sigils

| Id | Cell | Size @ offset | Tint | Used on | Replaces (old cell) |
|---|---|---|---|---|---|
| `sigil_divine` | 0,14 | 15×15 @ 0,1 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_mage` | 1,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_mystech` | 2,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_performer` | 3,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_sorcerer` | 4,14 | 14×16 @ 1,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_brave` | 5,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_chymist` | 6,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_hellion` | 7,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_honorable` | 8,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |
| `sigil_warrior` | 9,14 | 16×16 @ 0,0 | color | Every merc card, tooltip and tradition list | Tradition sigil (sword) (0,35) |

## Screenshots

Every screen, tab and popup, 1280×720 frame, in reading order.

**01 · Game HUD**

![Game HUD](screenshots/01_game_hud.png)

**02 · HUD › notifications panel**

![HUD › notifications panel](screenshots/02_hud_notifications_panel.png)

**03 · HUD › My Mercs window (1280×644, bottom bar visible)**

![HUD › My Mercs window (1280×644, bottom bar visible)](screenshots/03_hud_my_mercs_window_1280_644_bottom_bar_visible.png)

**04 · HUD › My Contracts window**

![HUD › My Contracts window](screenshots/04_hud_my_contracts_window.png)

**05 · Merc Viewer › Overview**

![Merc Viewer › Overview](screenshots/05_merc_viewer_overview.png)

**06 · Merc Viewer › Equipment**

![Merc Viewer › Equipment](screenshots/06_merc_viewer_equipment.png)

**07 · Merc Viewer › Relationships**

![Merc Viewer › Relationships](screenshots/07_merc_viewer_relationships.png)

**08 · Merc Viewer › Actions**

![Merc Viewer › Actions](screenshots/08_merc_viewer_actions.png)

**09 · Merc Viewer › Perks**

![Merc Viewer › Perks](screenshots/09_merc_viewer_perks.png)

**10 · Merc Viewer › Drawbacks**

![Merc Viewer › Drawbacks](screenshots/10_merc_viewer_drawbacks.png)

**11 · Merc Viewer › Skills**

![Merc Viewer › Skills](screenshots/11_merc_viewer_skills.png)

**12 · Merc Viewer › Metrics**

![Merc Viewer › Metrics](screenshots/12_merc_viewer_metrics.png)

**13 · Merc Viewer › Coaching PIP dialog**

![Merc Viewer › Coaching PIP dialog](screenshots/13_merc_viewer_coaching_pip_dialog.png)

**14 · Contract Viewer**

![Contract Viewer](screenshots/14_contract_viewer.png)

**15 · Contract Viewer › filter popup**

![Contract Viewer › filter popup](screenshots/15_contract_viewer_filter_popup.png)

**16 · Contract Viewer › Contract Complete results**

![Contract Viewer › Contract Complete results](screenshots/16_contract_viewer_contract_complete_results.png)

**17 · Dispatch Window**

![Dispatch Window](screenshots/17_dispatch_window.png)

**18 · Client Viewer › People**

![Client Viewer › People](screenshots/18_client_viewer_people.png)

**19 · Client Viewer › Places**

![Client Viewer › Places](screenshots/19_client_viewer_places.png)

**20 · Client Viewer › Orgs**

![Client Viewer › Orgs](screenshots/20_client_viewer_orgs.png)

**21 · Promotions › tab 1**

![Promotions › tab 1](screenshots/21_promotions_tab_1.png)

**22 · Promotions › tab 2**

![Promotions › tab 2](screenshots/22_promotions_tab_2.png)

**23 · Promotions › tab 3**

![Promotions › tab 3](screenshots/23_promotions_tab_3.png)

**24 · Mercday › Plans**

![Mercday › Plans](screenshots/24_mercday_plans.png)

**25 · Mercday › Customize**

![Mercday › Customize](screenshots/25_mercday_customize.png)

**26 · Finance › tab 1**

![Finance › tab 1](screenshots/26_finance_tab_1.png)

**27 · Finance › tab 2**

![Finance › tab 2](screenshots/27_finance_tab_2.png)

**28 · Finance › tab 3**

![Finance › tab 3](screenshots/28_finance_tab_3.png)

**29 · Finance › tab 4**

![Finance › tab 4](screenshots/29_finance_tab_4.png)

**30 · Finance › tab 5**

![Finance › tab 5](screenshots/30_finance_tab_5.png)

**31 · Finance › Hiring (applicants, fit stars)**

![Finance › Hiring (applicants, fit stars)](screenshots/31_finance_hiring_applicants_fit_stars.png)

**32 · Legal › Permits**

![Legal › Permits](screenshots/32_legal_permits.png)

**33 · Legal › Fines**

![Legal › Fines](screenshots/33_legal_fines.png)

**34 · Legal › Fine review dialog**

![Legal › Fine review dialog](screenshots/34_legal_fine_review_dialog.png)

**35 · Legal › Bailout**

![Legal › Bailout](screenshots/35_legal_bailout.png)

**36 · Legal › Bail review dialog**

![Legal › Bail review dialog](screenshots/36_legal_bail_review_dialog.png)

**37 · Bazaar › tab 1**

![Bazaar › tab 1](screenshots/37_bazaar_tab_1.png)

**38 · Bazaar › tab 2**

![Bazaar › tab 2](screenshots/38_bazaar_tab_2.png)

**39 · Bazaar › tab 3**

![Bazaar › tab 3](screenshots/39_bazaar_tab_3.png)

**40 · Metrics Viewer › tab 1**

![Metrics Viewer › tab 1](screenshots/40_metrics_viewer_tab_1.png)

**41 · Metrics Viewer › tab 2**

![Metrics Viewer › tab 2](screenshots/41_metrics_viewer_tab_2.png)

**42 · Metrics Viewer › tab 3**

![Metrics Viewer › tab 3](screenshots/42_metrics_viewer_tab_3.png)

**43 · Locked page (lock state)**

![Locked page (lock state)](screenshots/43_locked_page_lock_state.png)

