# SCENES_DELTA — 2026-09-25 (reworked)

**NEW** / **CHANGED** / **REMOVED**. Only scenes that changed are listed; everything else is as in the earlier packages.

## CHANGED — GameHUD.tscn / MenuButton.tscn
```gdscript
# MenuButton.tscn
@export var locked: bool = false          # NEW: dim style + lock badge; pressed → emits locked_pressed instead of pressed
@export var locked_tooltip: String = ""
signal locked_pressed
```
GameHUD: 7th button **My Bazaar** → `locked = not entitlements.bazaar`; `locked_pressed` → `FeatureLockDialog` (plan vs. upgrade copy); `pressed` → SubWindow(`BazaarViewer.tscn`). Rename "My Subscription" → "My Mercday".

## CHANGED — DecisionButtons.tscn (Contract Viewer)
Theme only: Accept/Reject StyleBoxes and white icons (README A2).

## CHANGED — MetricsViewer.tscn
- `GraphTabs.tscn` → HBox of `TabButton` ×3 (`icon_cols = 16`, `icon_px = 1.5`), attached to the chart panel.
- **REMOVED** `ScaleSelector.tscn` (4 buttons).
- **NEW** `OptionDropdown.tscn` ×2:
```gdscript
@export var label: String                 # "Period" / "Scale"
@export var options: Array[Dictionary]    # [{key, label, enabled, reason}]
@export var selected: StringName
@export var disabled: bool                # locked graph
signal option_selected(key: StringName)
```
- MetricsViewer:
```gdscript
@export var period: Period = Period.ALL_TIME   # ALL_TIME, YTD, M6, Y1, Y3, Y5
@export var scale: Scale = Scale.MONTH         # DAY, WEEK, MONTH, QUARTER
func _valid_scales(span_days: int) -> Array    # DATA_DELTA §6
func _snap_scale(want: Scale, span_days: int) -> Scale   # nearest valid, tie → larger
```
- MercSelector: popup anchored to its own button (fix).

## CHANGED — MercViewer.tscn (Overview)
- **REMOVED** `LevelModeList.tscn`.
- **NEW** `CoachingBox` (Label "Coaching" + `CoachButton` + Label "Plan: …").
- **NEW** `CoachDialog.tscn`
```gdscript
@export var merc: MercData
@export var current_mode: StringName      # from GameState.pip_modes (default &"Auto")
var draft_mode: StringName
signal confirmed(mode: StringName)        # → GameState.pip_modes[merc.id] = mode
signal cancelled
# Confirm.disabled = draft_mode == current_mode
```
- **NEW** `PipModule.tscn`
```gdscript
@export var mode: StringName
@export var icon: Texture2D               # assets/icons/pip_*_8x8.png (white; modulate by group color)
@export var group_color: Color            # Standard #9cc6ef · Combat #e8583f · Skill #6cc36a
@export var description: String
@export var selected: bool
@export var is_current: bool              # "Current" tag
@export var locked: bool                  # grey + FeatureLock(upgrade, tier, tiers)
signal picked(mode)
# Hovering the FeatureLock child hides this module's tooltip.
```
- Lifepath list: bind to `merc.lifepath` (bug fix).

## CHANGED — SubscriptionViewer.tscn › SkillTree
- **REMOVED** hand-placed node positions and the `routes` table.
- **NEW** `TreeLayout.gd` (static): `grid_to_px(col, row)`, `build_connectors(tree, cats, entitlements) -> Array[Segment]` implementing DATA_DELTA §5 (exits, spines, gate lanes, text gaps, colors, opacity, convergence gradients).
```gdscript
class Segment: var from: Vector2; var to: Vector2; var color_a: Color; var color_b: Color; var alpha: float   # color_b ≠ color_a → gradient
```
- `CustomizeBlock.tscn`: icon glow now reads `PulseClock` (only the icon glows).
- `CategoryBox.tscn`: `@export var progress: float` → icon color `cat_color(progress)`; glow at 1.0; tooltip adds "x/y upgrades owned".
- **NEW** `RequirementGate.tscn` (52×26)
```gdscript
@export var have: int
@export var need: int                     # text "have/need"; color gate_color(have/need); glow when have ≥ need
```

## NEW — PulseClock (autoload)
See README B4. `signal pulse(g: float, sweep: PackedFloat32Array)`; or expose `g` / `sweep` as globals for shaders.

## NEW — BazaarManager (autoload)
```gdscript
var catalog: Array[ItemData]              # DATA_DELTA §7
var cart: Dictionary = {}                 # item_id -> qty
var orders: Array[OrderData] = []
func delivery_days() -> int               # by entitlements.bazaarSpeed
func available(item: ItemData) -> bool    # item.rarity <= entitlements.bazaarRarity
func cart_total() -> int
func can_checkout() -> bool               # cart not empty and cart_total() <= GameState.money
func place_order() -> OrderData           # spend, clear cart, append order (placed_day = GameClock.day, days = delivery_days())
func is_delivered(o: OrderData) -> bool   # o.placed_day + o.days <= GameClock.day
signal cart_changed
signal order_placed(order)
signal order_arrived(order)               # emit from the day tick when an order crosses its arrival day
```

## NEW — BazaarViewer.tscn
`VBox › BazaarTabs(TabButton ×3: Orders, Cart, Shop) + Panel(ShopPage | CartPage | OrdersPage) + LockedPage`
```gdscript
@export var start_tab: Tab = Tab.SHOP
```

### ShopPage.tscn
`HBox › FilterPanel + VBox(TopBar(SearchField, SortDropdown), Breadcrumb, ScrollContainer › GridContainer(columns=5) › ItemCard ×N | EmptyState)`

### FilterPanel.tscn
```gdscript
@export var department: StringName = &"all"
@export var subtypes: Dictionary          # department -> Array[StringName] (checked)
@export var price_preset: StringName = &"any"   # any, u50, 50, 150, 400
@export var price_custom: Vector2i = Vector2i(-1, -1)   # -1 = open end; overrides preset when set
@export var rarities: Array[int]          # empty = all unlocked
signal filters_changed
```

### ItemCard.tscn
```gdscript
@export var item: ItemData
@export var qty_in_cart: int              # 0 → Add to Cart; else − qty +
signal add_pressed
signal remove_pressed
```

### CartPage.tscn
`HBox › CartList(CartRow ×N | EmptyState) + OrderSummary`
- CartRow: `@export var item`, `@export var qty`; signals `qty_changed(qty)`, `removed`.
- OrderSummary: rows + `CheckoutButton` (disabled + reason when `not can_checkout()`).

### CheckoutDialog.tscn / OrderPlacedDialog.tscn
ConfirmDialog chrome (green). Place Order → `BazaarManager.place_order()` → OrderPlacedDialog (Keep Shopping → Shop, View Orders → Orders/All).

### OrdersPage.tscn / OrderCard.tscn
```gdscript
@export var filter: StringName = &"all"   # all, transit, delivered
# OrderCard
@export var order: OrderData              # id, placed_day, days, lines [{item_id, qty}], total
# progress cells = 20 if delivered else round(elapsed / days × 20)
```


---
# Additions — rework (E–G)

## CHANGED — GameHUD.tscn
- Menu grid order: Mercs, Contracts, Clients / Promotions, Mercday, Finance / Legal, Bazaar, Metrics. No empty slots.
- `MenuButton` hover → `z_index = 25`. Promotions button: same locked variant as Bazaar (`locked: bool`, `lock_dialog` copy per feature).
- My Finance dot: `FinanceManager.has_offers() or PromotionsManager.has_unseen()`.

## CHANGED — FinanceViewer.tscn
- Tabs: Overview · Loans · Payroll · **Hiring** · Invest. Hiring = `HiringTab.tscn`.
- LoanRequestWindow › EnvoySlots now = `OddJobCrew.tscn` with `max = entitlements.odd_jobs`; 0 → FeatureLock(label "Add Merc").

## CHANGED — MercViewer.tscn
- `@export var applicant: ApplicantData = null` — when set: identity from applicant, `CoachModule`, `SalaryModule`, Metrics tab → disabled (modulate a 0.4, grayscale shader, mouse_filter IGNORE).
- LevelBadge XP tooltip: `mouse_filter = IGNORE`, hide on `mouse_exited` immediately.

## CHANGED — FeatureLock.tscn
- `@export var label: String = ""` — non-empty = label mode (full greyed button + lock; whole button opens dialog). `@export var height / font_size`.

## NEW — OddJobCrew.tscn (shared)
- Root: HBox 3 cols › SendMercsPanel (EnvoySlot ×(filled+1, ≤max)) · PayMercsPanel (span 2, only when ≥1 merc) · MercPicker (modal).
- `@export var max: int`, `@export var team: Array[int]`, `@export var candidates: Array[{id, name, fit}]` (fit 0.5–5), `@export var per: int`, `@export var default_pay: int`, `@export var money: int`, `@export var tip_text / pick_desc: String`
- `signal team_changed(team)`, `signal pay_changed(per)`

## NEW — TextEntryDialog.tscn (shared)
- `@export var title / placeholder / value: String`, `@export var max_length: int = 64`
- `signal done(text)`, `signal cancelled` — Enter = done, Esc = cancel, physical keys accepted.

## NEW — ConfirmDialog.tscn (shared)
- `@export var title / body / cta: String`, `@export var rich: ConfirmRich = null` (kicker, crew[], money[], outcome)
- `signal confirmed`, `signal cancelled` — while open, parent dialogs hide their close X.

## NEW — My Legal
- **LegalViewer.tscn** (root (HUD › My Legal)) — VBox › LegalTabs + Panel(PermitsPage | FinesPage | BailoutPage) + dialog stack
  - `@export var start_tab: Tab  # PERMITS, FINES, BAILOUT`
  - `# tab dot = any unread fine / capture`
- **LegalManager (autoload)** (data) — Node
  - `var permits: Dictionary  # loc_id → {ops, tele} (kept even if upgrade lapses)`
  - `var fines: Array[FineData]  # loc, crime, mercs, contract, issued, due, amount, unread`
  - `var captured: Array[CaptureData]  # merc, loc, crime, contract, since, sentence, bail, unread`
  - `func late_fee(f) / custody_fee(c) -> int`
  - `signal odd_job_resolved(target, success)`
- **LocationCard.tscn** (x N (HScroll, ~3.5 visible)) — PanelContainer(330w) › VBox(Icon, Name, Difficulty PixelSlider, Rules, Permissions ×3, Request)
  - `@export var location: LocationData`
  - `# permission states: ACTIVE ✓ · OWNED_INACTIVE ! · NONE ✗`
  - `signal request_pressed`
- **PermitRequestDialog.tscn** (x1 (modal)) — Panel › PermitRow ×2 + GoodStanding(ViolationRow ×N › Review)
  - `# PermitRow locked (FeatureLock) if opsPermits/teleport tier < location.scope`
  - `signal permit_requested(loc, kind)`
- **FineRow / CapturedRow.tscn** (x N) — PanelContainer › HBox(…, Review)
  - `@export var data: FineData | CaptureData`
  - `# NotificationDot while unread; Review marks read`
- **ReviewDialog.tscn** (x1 (modal)) — Panel › Facts + ContractModule(link) + Relationship + Money + [Odd Job | Pay]
  - `@export var target: FineData | CaptureData`
  - `# Relationship locked unless entitlements.clientOpinion`
  - `signal paid / odd_job_pressed`


- **OddJobWindow.tscn** — Panel › Facts ×4 + OddJobCrew + SuccessOdds(20 cells) + [Cancel | Renegotiate/Break Out] + outcome line

## NEW — My Promotions + Hiring

- **PromotionsViewer.tscn** (HUD › My Promotions, [LOCK] promotions) — Control › VBox (PromotionsTabs ×2, Panel)
  - `@export var mode: String = "job"  # job = Advertise Job · promo = Advertise Guild`
- **CampaignCard.tscn** — PanelContainer
  - `@export var campaign: CampaignData`
  - `signal view_applicants / ended`
- **CampaignBuilder.tscn** — Window › (TypeList, Config: Name + Duration + FilterGroups)
  - `# Filters are data-driven TraitFilterDefs grouped Value / Identity / Physical / Mental; locked defs render a FeatureLock`
  - `signal launched(CampaignData)`
- **FilterGroup.tscn** — VBox › HeaderButton (caret, label, active count) · Body
  - `@export var expanded: bool`
- **RangeSlider.tscn** — Control › Track · Fill · ThumbLo · ThumbHi
  - `@export var min_value / max_value / step`
  - `signal range_changed(lo, hi)  # nearest thumb follows the pointer`
- **TextEntryDialog.tscn** — Window › LineEdit + OnScreenKeyboard
  - `@export var max_length: int = 64`
- **HiringTab.tscn** (Finance › Hiring) — HBox › FilterList(290w, FilterGroup ×4) · VBox(Header + SortDropdown, ApplicantGrid 3 cols) + HireOfferDialog + ApplicantViewer(MercViewer applicant mode) + ConfirmDialog
  - `# ApplicantCard.dot = applicant.unseen; View/Offer/Reject set unseen = false`
- **ModuleTile.tscn** (Contract Type / Location picker) — Panel › HBox(Image 64×64, Stats VBox) + Name
  - `@export var image: Texture2D`, `@export var received / completed / failed: int`, `@export var relationship: int = INT_MIN  # hidden for contract types`, `@export var disabled_reason: String`
- **StarRangePicker.tscn** — 2 rows (Min / Max) × 5 stars, half-star hit zones; color = difficulty color of the row value
- **PromotionsManager (autoload)** — `campaigns: Array[CampaignData]`, `applicants: Array[ApplicantData]`, `has_unseen() -> bool`, `launch(c)`, `end(id)`, `hire(id, salary)`, `counter(id, salary, team)`; `signal applicant_arrived(a)` (sets unseen)
