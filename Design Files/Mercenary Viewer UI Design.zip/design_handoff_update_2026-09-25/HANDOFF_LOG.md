# UX Handoff Log

Each entry = one package delivered to the Godot GUI agent. The newest entry is the baseline for the next `/download-ux-guide`.

## 2026-09-23 — Initial full handoff (baseline v1)
**Package:** `design_handoff_mercenary_gui/` (full, not a delta)
**Baseline snapshot:** `design_handoff_mercenary_gui/reference_html/` (use this to diff future changes)

Delivered:
- Screens: Game HUD, Merc Viewer (8 tabs incl. Metrics), Contract Viewer, Dispatch Window, Metrics Viewer
- README.md (screens, tokens, deployment walkthrough), SCENES.md (all reusable scenes + exports + autoloads), DATA.md (Resources + game rules), ASSETS.md (icons, fonts, theme StyleBoxes, placeholders)
- assets/icons/ — 20 PNGs (12 UI icons + 8 Merc Viewer tab icons)
- sample_data/ — sample_data.json, dispatch_scoring.js, metrics_history_generator.js

Feature state at this date:
- Accept → Dispatch (5 slots, dashed optional slots) → Active contract (crew portraits, payout/odds tooltips, Estimated Return Time)
- GameState shared store: merc status derived from active teams across viewers
- Metrics: Merc/Contract/Guild graphs, draw-on animation, Y-focus, Day/Week/Month/Quarter rules, contract-type filter
- HUD: My Mercs, My Contracts, My Metrics (6 empty slots)

Known open items: time progression/returns, 6 HUD buttons + Settings, real portraits/contract art/sigils, money bar values.

## 2026-09-24 — Metrics Viewer complete guide (scoped full guide)
**Package:** `design_handoff_metrics_2026-09-24/` (complete for Metrics only; supersedes Metrics sections of baseline v1)
**Baseline snapshot:** `design_handoff_metrics_2026-09-24/reference_html/Metrics Viewer.dc.html` for Metrics Viewer, Feature Lock, Locked Page. All other screens still diff against `design_handoff_mercenary_gui/reference_html/`.

Delivered: README (layout, every state, locks), SCENES, DATA (metric defs, aggregation, compare math, entitlements), 31 screenshots, 6 icons.
New vs v1: Investment Portfolio, Vacation Days Taken, All Mercs averages mode, Show Averages + compare arrows, Merc Comparison, all Metrics locks (marked Phase 2 / optional for now).
Fix shipped: embedded Metrics tab no longer shows a double LockedPage.
Note: Metrics Viewer changed after this package (icon tabs, Period/Scale dropdowns, tabs attached to chart, compare-popup fix). Those changes are still undelivered; the next Metrics delta should diff against this snapshot.

## 2026-09-25 — Dispatch Window complete guide (scoped full guide)
**Package:** `design_handoff_dispatch_2026-09-25/` (complete for Dispatch only; supersedes Dispatch sections of baseline v1)
**Baseline snapshot:** `design_handoff_dispatch_2026-09-25/reference_html/Dispatch Window.dc.html` for Dispatch Window.

Delivered: README (layout, every state and dialog), SCENES, DATA (travel, scoring, odds, Optimize, preview, payload), 23 screenshots, dispatch_scoring.js.
New vs v1: Mercenary Bonus + Guild Cut preview rows, notes glyph on costs; entry point Accept/Reject recolored.
Undelivered elsewhere (not in this package): Merc Viewer Coaching/PIP dialog + Lifepath fix, Subscription Viewer (Skill/Combat PIP tiers, category progress icons), HUD "My Mercday" rename.

## 2026-09-25 — Update (reworked): Bazaar + Legal + Promotions + Hiring + all changes (delta)
**Package:** `design_handoff_update_2026-09-25/` (delta since the Dispatch guide; the first version of this package was never deployed, so this rework supersedes it and contains everything). Parts A–D (original) → E changes → F Legal → G Promotions + Hiring → H verify. Runbook: `RUNBOOK.md`.
**Baseline snapshot:** `design_handoff_update_2026-09-25/baseline_snapshot/` (all 20 screens/components) — diff source for the next update.

Delivered: README (91 screenshots), SCENES_DELTA, DATA_DELTA, 50 icons, reference_html (20 DCs + support.js, legal-data.js, promo-core.js, fit-frame.js).
Original (A–D): HUD My Mercday rename + locked My Bazaar; Contract Accept/Reject colors; Metrics icon tabs + Period/Scale dropdowns; Merc Viewer Coaching; Customize rule-based layout; Bazaar (Shop/Cart/Orders).
Added in rework: HUD 3×3 re-layout (Promotions, Finance, Legal, Bazaar, Metrics), gavel icon, tooltip z-order; Finance › Hiring tab + Odd Jobs gate on Request a Loan; Merc Viewer applicant mode + XP tooltip fix; Customize full re-layout (Limits/Bazaar arms, two bottom branches, single leg renderer, exitDy, cost billing), new upgrades (Operations/Teleportation Permits, Representation, Advisory Counsel, Who Knows a Guy, Discrimination IV Hiring Discrimination); shared OddJobCrew, TextEntryDialog, ConfirmDialog, FeatureLock label mode, unified NotificationDot; My Legal (Permits/Fines/Bailout, Review, Odd Jobs); My Promotions (Advertise Job/Guild, CampaignBuilder); Hiring (filters, sort, offer/counter-offer, applicant view).
Open: tree upgrades for Direct Sale/Radio/Sponsorship; applicant generation + timing; time advancement (Odd Jobs, campaigns, counter-offers); Settings (Odd Job Default Bonus); real art.
