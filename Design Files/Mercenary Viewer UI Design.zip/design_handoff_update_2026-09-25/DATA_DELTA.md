# DATA_DELTA — 2026-09-25 (reworked)

## 1. Upgrades (Customize) — changed + new
`monthly[i]` = monthly cost of tier *i+1* (owning tier *t* costs the sum of the first *t* values). `req: {ids, tier}` = combined tiers across those upgrades.

| id | Name | Cat (+ also) | Tiers | Monthly | Requires | Status |
|---|---|---|---|---|---|---|
| combatpip | Combat PIP | coaching | **Support**, Defensive, Offensive | 2, 2, 2 | pip 1 | CHANGED (was 2 tiers) |
| skillpip | Skill PIP | coaching | **Existing Skills**, **New Skills**, Universal, Ancestral, Tradition | 2 ×5 | pip 1 | CHANGED (was 3 tiers) |
| pip | Performance Improvement Plan | coaching | "Unlock Random, Utility, Skills, and Stats-based Performance Improvement Plans." | 10 | — | CHANGED (text) |
| discrim | Discrimination | insights (+ **lessLegal**) | age · ancestry · bloodline | 20, 35, 50 | — | CHANGED (alsoCat) |
| criminal | Criminal Background Check | insights (+ **lessLegal**) | Criminality rating | 10 | discrim + background ≥ 6 | CHANGED (alsoCat) |
| education | Education Exam | insights | Reveal Knowledges | 7 | **background + aptitude ≥ 3** | CHANGED (was background ≥ 2) |
| survey | Employee Survey | **metricsCat** | quarterly survey | 5 | **mercmetrics ≥ 1** | CHANGED |
| peer | Peer Review | **metricsCat** | opinions of other mercs | 5 | survey ≥ 1 | CHANGED (cat) |
| customer | Customer Satisfaction | **metricsCat** | client opinions | 5 | **contractmetrics + survey ≥ 2** | CHANGED |
| fastmetrics | **Rapid Survey** | **metricsCat** | monthly · weekly · daily · instant · predictive | 9 ×5 | **peer + customer ≥ 2** | CHANGED (renamed; req) |
| oddjobs | Odd Jobs | **lessLegal** | 1 merc (+ Odd Job Default Bonus setting) · 2 mercs · 3 mercs | 15, 25, 40 *(placeholder)* | — | NEW |
| bazaar | Bazaar | **bazaarCat** | Unlock the Bazaar (orders take 20 days) | 10 *(placeholder)* | — | NEW |
| betteritems | Better Items | bazaarCat | Common · Uncommon · Rare · Very Rare | 5 ×4 | bazaar 1 | NEW |
| fasteritems | Faster Items | bazaarCat | 25 % (15 d) · 30 % (14 d) · 45 % (11 d) · 50 % (10 d) · 2-Day | 2 ×5 | bazaar 1 | NEW |

Category membership (for Total and progress): `U.cat == id or id in U.alsoCat`.

## 2. Entitlements (added / renumbered)
| Key | Rule |
|---|---|
| lvSupport / lvDefensive / lvOffensive | combatpip ≥ 1 / 2 / 3 |
| lvExisting / lvNewSkills / lvUniversal / lvAncestral / lvTradition | skillpip ≥ 1 / 2 / 3 / 4 / 5 |
| oddJobs | `int` = oddjobs tier (0 locked) |
| bazaar | bazaar ≥ 1 |
| bazaarRarity | betteritems tier: 0 Ordinary only · 1 Common · 2 Uncommon · 3 Rare · 4 Very Rare |
| bazaarSpeed | fasteritems tier 0–5 |
Upgrades only apply while `plan == ENTERPRISE`.

## 3. PIP modes (CoachDialog)
| Mode | Group | Gate | Description (tooltip) |
|---|---|---|---|
| Auto | Standard | — | Allow the merc to choose what's best for them each time they level up. |
| Random | Standard | pip | Coach the merc to let chaos reign! Their level-ups will be completely randomized. |
| Utility | Standard | pip | Have your merc focus on features that make them useful outside of combat as they level up. |
| Stats | Standard | pip | Have your merc focus on improving their statistics and bonuses rather than gaining new abilities as they level up. |
| Support | Combat PIP | lvSupport | Have your merc focus on teamwork-based combat features as they level up! |
| Defensive | Combat PIP | lvDefensive | Have a merc focus on defensive abilities as they level up! |
| Offensive | Combat PIP | lvOffensive | Have a merc focus on offensive abilities as they level up! |
| Skills | Skill PIP | pip | Direct your merc to focus on improving their skills as they level up. |
| Existing Skills | Skill PIP | lvExisting | Direct your merc to focus only on improving their existing skills, where possible. |
| New Skills | Skill PIP | lvNewSkills | Direct your merc to always learn new skills, where possible. |
| Universal | Skill PIP | lvUniversal | Have a merc focus on broader skills as they level up! |
| Ancestral | Skill PIP | lvAncestral | Have a merc focus on their ancestry as they level up! |
| Tradition | Skill PIP | lvTradition | Have a merc focus on their tradition as they level up! |
| Spell | Skill PIP | lvSpell (Magic PIP) | Have a merc focus on spellcasting as they level up! |
Storage: `GameState.pip_modes[merc_id]`. Effective mode = stored mode if its gate is met, else Auto; `prune_pip_modes()` on `SubscriptionManager.changed` deletes unmet entries.

## 4. Color functions (Customize)
```
tier_color(i, n)   # existing: red #e8583f → yellow #f2d33d → green #4ee06a, f = i/(n-1)
cat_color(f)       # icons: c = tier_color at f; brightness k = 0.30 + 0.70·f; rgb × k   (f = owned tiers / total tiers)
gate_color(f)      # requirement modules: same, k = 0.55 + 0.45·f   (f = have/need)
mix(colors)        # channel-wise average (converging lines)
```
Line color out of element E:
- Base Plan → `#f28c28` (non-Enterprise: `#2b4f8a`).
- Category → `cat_color(progress)` if progress > 0, else the incoming color (parent category / Base orange).
- Upgrade → `tier_color(tier-1, max)` if owned, else `gate_color(0)` (dark red).
- Requirement module → `gate_color(have/need)`.
- Into a module: each source leg = source color; its **last segment** is a linear gradient to `mix(sources)`; the merged stub = `mix(sources)`.
- Opacity: 0.5 when the target isn't available (module not met, or plan isn't Enterprise), else 1.

## 5. Customize layout rules
Grid: `x = 800 + col·135`, `y = 500 + row·70` (content layer; Base at 0,0). Node box 64 (Base 72); category box 140×44.

| id | col,row | | id | col,row |
|---|---|---|---|---|
| base | 0,0 | | discrim | 4,4 |
| seats / contracts | −4,−1 / −4,1 | | criminal | 6,6 |
| pip | 0,−6 | | background | 4,8 |
| combatpip / skillpip | −1,−10 / 1,−10 | | contractmetrics / mercmetrics | 6,11 / 6,13 |
| magicpip | 0,−14 | | survey | 8,13 |
| personality / readiness / brawn / aptitude | 6,−3 / 6,−1 / 6,1 / 6,3 | | customer / peer | 10,11 / 10,15 |
| skilltest / education | 8,3 / 8,6 | | fastmetrics | 12,13 |
| oddjobs | 2,4 | | bazaar | −2,6 |
| | | | betteritems / fasteritems | −3,10 / −1,10 |

Categories (`at`, how Base reaches it, where kids hang):
| id | at | via | side |
|---|---|---|---|
| limits | −2,0 | left (Base left edge → box) | left spine |
| coaching | 0,−3 | top | up |
| bazaarCat | −2,4 | bottom (Base → down → across → down) | down |
| testing | 4,0 | right trunk | right spine |
| lessLegal | 2,2 | right trunk | down (+ link → Discrimination top) |
| insights | 2,8 | right trunk | right spine (kids: discrim, background, metricsCat) |
| metricsCat | 4,12 | child of insights | right spine |

Connector rules:
- **Trunk** x = midpoint between Base's right edge and the nearest trunk category's left edge; runs from Base's y to the lowest trunk category.
- **Spine** x = midpoint between the category's edge and its kids' facing edge; spans the category's y and all kid y's.
- **Exit**: center of the leaving side. Several lines leaving the same side share the exit and fork later.
- **Gate lanes** (requirement modules):
  - Sources all ≥ 2 columns left of target → horizontal: converge at `target.left − 118`; module centered at `target.left − 59`.
  - Sources all below → vertical up: converge at `target.textBottom + 92`; module at `textBottom + 46`.
  - Otherwise vertical down: converge at `target.top − 92`; module at `target.top − 46`.
- **Text gaps**: leaving a box downward: 10 px stub (8 for categories) → gap until `cy + 88` (node label) / `cy + 76` (category Total) → resume.
- Line thickness 4 px. Requirement module 52×26 with a 5 px background outline so lines don't touch it.

## 6. Metrics — Period / Scale
- Period days: All Time = full history · YTD = `day % 360` (or 360 if 0; in-game year = 12 × 30 days) · 6m 180 · 1y 360 · 3y 1080 · 5y 1800.
- **Effective span** = `min(period_days, history_available)` (merc graphs: since hire). Window = last *span* days.
- Valid scales by span: Days ≤ 180 · Weeks ≤ 360 · Months ≥ 180 · Quarters ≥ 360. (Every span has ≥ 1 valid scale.)
- Snap: nearest valid by index in [Days, Weeks, Months, Quarters]; tie → larger. Default Months.
- Invalid-option reasons: "Days need a period of 6m or less", "Weeks need a period of 1y or less", "Months need a period of 6m or more", "Quarters need a period of 1y or more".

## 7. Bazaar
**Rarities** (color): Ordinary `#a0a8b8` · Common `#f3ead7` · Uncommon `#6cc36a` · Rare `#5aa6e8` · Very Rare `#a36ce8`. Price multiplier 1 · 2.5 · 6 · 15 · 40.

**Delivery days** by `bazaarSpeed`: 0 → 20 · 1 → 15 · 2 → 14 · 3 → 11 · 4 → 10 · 5 → 2 (2-Day). Delivery cost: Free.

**Departments → subtypes** (base price):
| Department | Base | Subtypes |
|---|---|---|
| Weapons | 40 | Swords, Axes, Bows, Daggers, Staves, Firearms |
| Armor | 50 | Light Armor, Medium Armor, Heavy Armor, Shields |
| Headwear | 25 | Helmets, Hoods, Hats, Circlets |
| Containers | 20 | Backpacks, Pouches, Quivers, Chests |
| Tools | 30 | Kits, Instruments, Navigation |
| Consumables | 8 | Potions, Rations, Scrolls, Bombs |
| Trinkets | 35 | Rings, Amulets, Charms |

**PLACEHOLDER catalog** (replace with real items): 5 items per subtype named "<Singular> 1–5"; rarity roll 30 % Ordinary · 25 % Common · 20 % Uncommon · 15 % Rare · 10 % Very Rare; price = `round(base × mult × (0.7…1.3))`.

**Price presets**: Any · Under 50 `[0,50)` · 50 to 150 `[50,150)` · 150 to 400 `[150,400)` · 400 & Above `[400,∞)`. Custom Min/Max inclusive; either end may be blank.

**Filters**: department AND (subtypes if any checked) AND price AND (rarities if any checked; always capped at `bazaarRarity`) AND search (name/subtype/department, case-insensitive). Counts shown next to each option are computed with the other filters applied.

**Sort**: Featured (fixed random order) · Price asc · Price desc · Rarity desc then price · Name A–Z.

**Order**: `{id, placed_day, days (delivery_days at purchase), lines [{item_id, qty}], total}`. In transit while `placed_day + days > today`; progress = elapsed / days. Dates show as "Mon D" (30-day months).


---
# Additions — rework (E–G)

## 1. Upgrades — new / changed (Customize)
| id | name | category (billed to) | requirement | n / month per tier | tiers |
|---|---|---|---|---|---|
| `opspermit` | Operations Permits | legalCat |  | [50, 50, 50] | 1. Request and use Operations Permits from most nations<br>2. Request and use Operations Permits from all nations<br>3. Request and use Operations Permits from other Domains |
| `teleport` | Teleportation Permit | legalCat | { id: 'opspermit', tier: 2 } | [50, 50, 50] | 1. Add a teleportation circle to your guild and use it<br>2. Request Teleportation Permits from all nations<br>3. Request Teleportation Permits from other Domains |
| `representation` | Representation | legalCat | { id: 'opspermit', tier: 1 } | [500, 500, 500] | 1. Very low chance for a fine or legal charge to be dismissed<br>2. Low chance for a fine or legal charge to be dismissed<br>3. Moderate chance for a fine or legal charge to be dismissed |
| `counsel` | Advisory Counsel | legalCat | { ids: ['representation', 'oddjobs'], tier: 5 } | [100, 100, 100, 100, 100] | 1. Boosts Renegotiate Odd Job success chances by 5% per merc<br>2. Boosts Renegotiate Odd Job success chances by 7% per merc<br>3. Boosts Renegotiate Odd Job success chances by 9% per merc<br>4. Boosts Renegotiate Odd Job success chances by 13% per merc<br>5. Boosts Renegotiate Odd Job success chances by 15% per merc |
| `whoknows` | Who Knows a Guy | lessLegal |  | [17, 17, 17, 17, 17, 17, 17, 17] | 1. Reduce future Bail and Fines by 5%<br>2. Reduce future Prison Time by 5%<br>3. Reduce future Bail and Fines by 20%<br>4. Reduce future Prison Time by 15%<br>5. Reduce future Bail and Fines by 25%<br>6. Reduce future Prison Time by 20%<br>7. Reduce future Fine Fees by 50%<br>8. Ignore future Fine Fees |
| `discrim` | Discrimination | lessLegal |  | [20, 35, 50, 65] | 1. See merc ancestry<br>2. See merc bloodline<br>3. See merc age<br>4. Hiring Discrimination: see and filter for these traits on applicants and job postings |
| `skilltest` | Skill Test | testing | { ids: ['readiness', 'aptitude'], tier: 2, exitDy: { aptitude: -18 } | [5] | 1. Reveal merc Tools |
| `education` | Education Exam | testing | { ids: ['background', 'aptitude'], tier: 6, exitDy: { aptitude: 18 } | [7] | 1. Reveal merc Knowledges |
| `criminal` | Criminal Background Check | insights | { ids: ['discrim', 'background'], tier: 6, sideExit: ['discrim'] } | [10] | 1. "See each mercs Criminality rating" |
| `fasteritems` | Faster Items | bazaarCat | { id: 'bazaar', tier: 1 } | [2, 2, 2, 2, 2] | 1. Deliveries arrive 25% faster<br>2. Deliveries arrive 30% faster<br>3. Deliveries arrive 45% faster<br>4. Deliveries arrive 50% faster<br>5. 2-Day delivery on all items |
- **Representation:** dismissal is rolled **once, when a fine or legal charge is incurred**. Baseline 1–10 % by tier band (very low / low / moderate), then flexed by the severity of the charge and the fine's reasoning (LegalManager). PLACEHOLDER numbers.
- **Who Knows a Guy:** affects **future** fines, bail, sentences and fees only (tier text says "future"); existing ones are unchanged.
- **Permits:** kept forever once bought; losing the Operations/Teleportation upgrade only disables using/requesting them.
- **Multi-source cost billing:** Advisory Counsel → Legal, Criminal Background Check → Insights, Education Exam → Testing.

## 2. Entitlements — added
| key | rule |
|---|---|
| `opsPermits` | `up.opspermit` (1 most nations · 2 all nations · 3 other Domains) |
| `teleport` | `up.teleport` (1 guild circle + most nations · 2 all nations · 3 other Domains) |
| `representation` | `up.representation` |
| `whoKnows` | `up.whoknows` (0–8) |
| `counsel` | `up.counsel` → Renegotiate +[0,5,7,9,13,15]% per merc |
| `oddJobs` | `up.oddjobs` = max mercs on any Odd Job (0 = locked) |
| `promotions` | plan == enterprise |
| `hiringDiscrim` | `up.discrim >= 4` — see/filter Ancestry, Bloodline, Age on applicants + job postings |
| `adDirect` / `adRadio` / `adSponsor` | `up.direct/radio/sponsor >= 1` — **no tree upgrades yet** (open item) |

## 8. Customize layout (exact values — port verbatim)
Grid: GX 150, GY 84, module 92 (Base 100), world 4600×2900, Base at (2600, 500+OY 780). Coordinates are grid units from Base.
```js
  place = { base: [0, 0],
    seats: [-5.5, -3.5], contracts: [-5.5, -1.5],
    pip: [0, -5.5], combatpip: [-1, -9.5], skillpip: [1, -9.5], magicpip: [0, -13.5],
    personality: [4, -6], readiness: [4, -4], brawn: [4, -2], aptitude: [4, 0], skilltest: [6, -2], education: [8.5, 1],
    bazaar: [-5.5, 2.5], betteritems: [-7.5, 1.5], fasteritems: [-7.5, 3.5], /* mirrors Limits: Bazaar row +2.5 ↔ Limits −2.5; Bazaar upgrade in the Seats/Contracts column */ // Bazaar runs left
    opspermit: [-1, 5.5], teleport: [-2, 10], representation: [0, 10],
    whoknows: [0.25, 6.5], oddjobs: [1.75, 6.5], discrim: [3.25, 6.5], /* evenly spaced (1.5 cols) */
    counsel: [1.75, 10 + 138 / 76], /* its join row (top − 92) = Representation's row, so Representation's line runs straight across */
    criminal: [5.25, 10], /* right of Discrimination; Discrimination's line leaves its right side and drops in */
    background: [6.5, 3.5],
    // Metrics hangs right of Background Check: Merc Metrics → Employee Survey → Peer Review; Contract Metrics + Employee Survey → Customer Satisfaction; Peer + Customer → Rapid Survey.
    contractmetrics: [10, 2.5], mercmetrics: [10, 4.5], survey: [12, 4.5], customer: [14, 2.5], peer: [14, 6.5], fastmetrics: [16, 4.5] }

  catDefs = [{ id: 'limits', name: 'Limits', at: [-3.5, -2.5], via: 'leftHigh', side: 'left', kids: ['seats', 'contracts'], desc: 'Upgrades that raise your guild\'s caps.' },
    { id: 'coaching', name: 'Coaching', at: [0, -2.5], via: 'top', side: 'up', kids: ['pip'], desc: 'Coach your mercs as they level up.' },
    { id: 'testing', name: 'Testing', at: [2, 0], /* level with Base + Aptitude: one straight line */ via: 'trunk', side: 'right', kids: ['personality', 'readiness', 'brawn', 'aptitude'], desc: 'Tests that reveal your mercs\' core stats.' },
    { id: 'bazaarCat', name: 'Bazaar', at: [-3.5, 2.5], via: 'leftLow', side: 'left', kids: ['bazaar'], desc: 'Buy gear for your mercs from the Bazaar.' },
    { id: 'legalCat', name: 'Legal', at: [-1, 3.5], via: 'bl', side: 'down', kids: ['opspermit'], desc: 'Permits, representation, and counsel for your guild.' },
    // Upgrades fed by several categories bill to exactly ONE (their cat): Advisory Counsel → Legal, Criminal Background Check → Insights, Education Exam → Testing.
    { id: 'lessLegal', name: 'Less Legal', at: [1.75, 3.5], via: 'bl', side: 'fork', kids: ['whoknows', 'oddjobs', 'discrim'], desc: 'Upgrades of questionable legality.' },
    { id: 'insights', name: 'Insights', at: [4.25, 3.5], via: 'br', side: 'right', kids: ['background'], desc: 'Upgrades that reveal hidden information about your mercs.' }]
```
Routing kinds: `leftHigh/leftLow` (Base left edge ±30 px, shared elbow x = midpoint of Base-left and the farther arm's category), `top`, `trunk` (right), `bl/br` (one drop 140 px below Base, then a left and a right branch that each split to their categories), `fork` (one drop, one bar, a drop into each kid), `right/left` (spine), `node` (from an upgrade's side). Merge boxes: see §5 of the original part + E4 (single `leg()` renderer, `exitDy`, `topExit`, `sideExit`).

## 9. Legal (LegalManager) — PLACEHOLDER numbers
- Locations `[name, nation, scope tier, ops cost, tele cost, avg difficulty, relationship −5…+5]`: see `locDefs` in the logic class of `reference_html/Legal.dc.html` (9 locations; scope 1 most nations, 2 restricted/all nations, 3 other Domain). Seed fines/captures: `reference_html/legal-data.js`.
- Late fee = `ceil(amount × 0.02)` per overdue day. Custody fee = 5 notes per day served. Fine total = amount + late fees; bail total = bail + custody fees.
- Good Standing = no unpaid fine and no captured merc in that location.
- Odd Job (Renegotiate / Break Out): duration 12 days; odds = `min(95, 30 + 20 × mercs + counsel% × mercs)` (counsel only on Renegotiate); pay up front. Renegotiate: success → fine × 0.5, failure → × 1.25. Break Out: success → released, no bail; failure → bail × 1.5.

## 10. Promotions + Hiring (PromotionsManager) — PLACEHOLDER numbers
| type | quality ★ | cost | unlock | notes |
|---|---|---|---|---|
| Word of Mouth | 1 | Odd Job pay (per merc, up front) | `oddJobs ≥ 1` | crew via OddJobCrew |
| Flyers | 2 | 5 / day | Enterprise | |
| Direct Sale | 3 | 40 / day | `adDirect` | **Advertise Guild only**; pick one Company |
| Radio | 4 | 80 / day | `adRadio` | |
| Sponsorship | 5 | 250 / day | `adSponsor` | pick one Company or Event |
- Cost = perDay × days (1–90), deducted at launch. End Campaign: no refund.
- **Filter defs (one list, data-driven)** — `mercDefs()` in `promo-core.js`: key, group (Value/Identity/Physical/Mental), kind (`slider2`, `trad`, `chips`, `range`, `min`), options, lock {entitlement, upgrade, tier, hire}. Removed: Perks, Drawbacks, Skills, Min Physical, Min Fit, Min Uniqueness. Added: Min Speed (Physical, unlocked with Mercday Pro).
- Contract targeting: Contract Type (Type 1–6), Difficulty [min, max] half-stars 0.5–5, Locations (Operations Permit required). Level and reward never targetable.
- **ApplicantData:** id, tradition, level (fixed), ask (salary/mo), uniq (count of traits none of your mercs have) + rarity (Common/Uncommon/Rare/Very Rare), fit (0.5–5 = average fit with your open contracts lacking a good match), from (campaign id or null = Walk-In), unseen, trait fields (ancestry, bloodline, age, heritage, criminality, stats{speed, cognition, vigor, dexterity, wile}, tools, knowledges).
- **Hire:** needs a free merc slot. Guild Opinion on hire = +1 at asking, extra +1 at ≥ +10 %, +2 at ≥ +25 %, +3 at ≥ +50 %, +4 at ≥ +100 % over asking.
- **Counter-offer** (offer < asking): odds = `clamp(100 − (1 − offer/ask) × 200 + Σ(fit × 3 per merc sent), 5, 95)`; Odd Job pay up front; resolves after a delay → hired or "Refused your counter-offer" (can still offer again).
