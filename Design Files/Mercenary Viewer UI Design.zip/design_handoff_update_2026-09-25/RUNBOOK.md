# RUNBOOK.md — runbook for the Godot 4 agent

You are implementing a **UI design delta** for the Godot 4 project (2D pixel-art guild-management GUI, 1280×720 base resolution). The HTML files in `reference_html/` are **design references**, not code to ship: rebuild each screen with Godot scenes (`.tscn`), `Control` nodes, `StyleBoxFlat` / theme items and GDScript, following the conventions already in the project from the earlier packages.

## Before you start
1. Read `README.md` fully (screenshots next to each section), then `SCENES_DELTA.md` and `DATA_DELTA.md`.
2. Already deployed (do not redo): `design_handoff_mercenary_gui/`, `design_handoff_metrics_2026-09-24/`, `design_handoff_dispatch_2026-09-25/`. Reuse their tokens, fonts (Silkscreen + Pixelify Sans), SubWindow chrome, TabButton, FeatureLock, QuantityStepper, PixelSlider, NotificationDot.
3. Import `assets/icons/*.png` with **Filter: Nearest, Mipmaps: off**. They are 1 px per art pixel; scale with integer `scale` (usually ×2–×4). White icons are tinted via `modulate`.
4. To inspect behavior, open any `reference_html/*.dc.html` in a browser (keep the folder intact; `support.js`, `legal-data.js`, `promo-core.js` must sit beside them). Set the `showScenes` prop (or read the `sceneMap` / `scenes` arrays in each file's logic class) to see intended `.tscn` names.

## Execution order (commit after each step; run the matching Part D/H checks)
| # | Task | README | Godot targets |
|---|---|---|---|
| 1 | Entitlements, GameState, PulseClock, TabButton icon props | Part B + DATA §2 (both) | `SubscriptionManager.gd`, `GameState.gd`, `PulseClock.gd`, `TabButton.tscn` |
| 2 | Existing-screen changes (skip A1 grid order + A5 positions) | Part A | Contract/Metrics/Merc/Subscription viewers |
| 3 | My Bazaar | Part C, verify D | `BazaarManager.gd`, `BazaarViewer.tscn` + children |
| 4 | Shared components | E5 | `NotificationDot`, `FeatureLock` (label mode), **`OddJobCrew.tscn`**, **`TextEntryDialog.tscn`**, **`ConfirmDialog.tscn`** |
| 5 | HUD 3×3 re-layout + My Promotions button + tooltip z-order + gavel icon | E1 | `GameHUD.tscn`, `MenuButton.tscn` |
| 6 | Finance: Odd Jobs gate on Request a Loan (use OddJobCrew) | E2 | `FinanceViewer.tscn` › LoanRequestWindow |
| 7 | Merc Viewer applicant mode + XP tooltip fix | E3 | `MercViewer.tscn` |
| 8 | Customize re-layout (port `place`/`catDefs` verbatim; one leg renderer) + new upgrades | E4, DATA §1/§8 | `SubscriptionViewer.tscn` › SkillTree, upgrade defs |
| 9 | My Legal | Part F, DATA §9 | `LegalManager.gd` (autoload), `LegalViewer.tscn` + children |
| 10 | My Promotions | G1, DATA §10 | `PromotionsManager.gd` (autoload; port `promo-core.js`), `PromotionsViewer.tscn` + builder |
| 11 | Finance › Hiring | G2, DATA §10 | `HiringTab.tscn`, `HireOfferDialog.tscn`, Finance tab |
| 12 | Final click-through | Part H | — |

## Rules
- **Data-driven, no duplication.** Filter sections, campaign types, upgrade defs and legal locations are tables; one renderer per kind (see `promo-core.js` `sec()` / `mercDefs()`). Keep PromotionsManager as the single source for both Promotions and Hiring.
- **Placeholders stay placeholders:** "Crime N", "Location N", "Company N", "Type N", "Ancestry N"… Do not invent names. Every number marked PLACEHOLDER lives in one constants block per manager.
- **Locks:** gate with `SubscriptionManager.entitlements()` keys only (never plan names in screens). Locked controls stay visible; clicking opens the FeatureLock dialog.
- **Scrolling:** windows and the HUD never scroll. Only the lists called out (permit slider, fines/bailout lists, campaign list, filter list, applicant grid, Contract Type / Location boxes, pickers) scroll.
- **Notification dots:** one round red style, no counts; clear on the actions listed per screen.
- **Confirm before spending notes** everywhere listed in E5.
- Don't read `baseline_snapshot/` (diff source for the next design update only).

## Acceptance
- Every screenshot in `screenshots/` 52–91 is reproducible in-game (same layout, copy, colors, lock states).
- Part D and Part H checklists pass.
- No console errors; no screen depends on another screen being opened first (managers seed their own placeholder data like `legal-data.js` / `mercPromoSeed`).

## Open items (not in scope — leave hooks)
Tree upgrades for Direct Sale / Radio / Sponsorship ads · real applicant generation + arrival timing · time advancement for Odd Jobs, campaigns and counter-offers · Settings page (Odd Job Default Bonus) · real art for locations, contract types, portraits.
