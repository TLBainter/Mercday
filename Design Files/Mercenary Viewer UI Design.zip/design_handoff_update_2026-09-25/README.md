# UX Update — 2026-09-25 (reworked): Bazaar + Legal + Promotions + Hiring + all changes

Delta since 2026-09-25 (Dispatch guide). Assumes these packages are already deployed: `design_handoff_mercenary_gui/` (baseline v1), `design_handoff_metrics_2026-09-24/`, `design_handoff_dispatch_2026-09-25/`. The first version of this package was **never deployed**, so this rework contains **everything** since the Dispatch guide. Anything not mentioned is unchanged. Tokens, fonts, SubWindow chrome and deployment steps: see baseline `README.md` / `ASSETS.md`.

**the implementer: start with `RUNBOOK.md`** (execution order, file map, acceptance checks).

## How to use this package
Work **top to bottom**. Each part builds on the one before it.
1. **Part A — Changes to existing screens** (original delta). ⚠ A1 (HUD grid) and A5 (Customize layout) are **superseded** by E1 and E4 — apply E1/E4 instead where they conflict.
2. **Part B — Dependencies** (entitlements, GameState, TabButton, PulseClock).
3. **Part C — Fresh build-out: My Bazaar.**
4. **Part D — Verify Bazaar.**
5. **Part E — More changes** (HUD re-layout, Finance, Merc Viewer, Customize re-layout, shared components).
6. **Part F — Fresh build-out: My Legal.**
7. **Part G — Fresh build-out: My Promotions + Finance › Hiring.**
8. **Part H — Verify everything added in E–G.**

Files:
| File | What it is |
|---|---|
| `RUNBOOK.md` | Runbook for the Godot agent (order, scene/script targets, acceptance checks) |
| `README.md` | This guide (behavior + screenshots) |
| `SCENES_DELTA.md` | New/changed scenes with `@export` vars and signals |
| `DATA_DELTA.md` | Upgrades, entitlements, Customize layout rules, Bazaar/Legal/Promotions data + formulas |
| `screenshots/` | 91 PNGs, numbered in reading order (all 1280×720 frames) |
| `assets/icons/` | 50 pixel icons, 1 px per art pixel (white icons are tinted with `modulate`) |
| `reference_html/` | All current prototypes + `support.js`, `legal-data.js`, `promo-core.js`. Open in a browser; `showScenes` prop overlays `.tscn` names |
| `baseline_snapshot/` | Diff source for the next update. **Not for the agent to read.** |

**[LOCK]** = subscription gating. If you are still on the Phase-1 entitlements stub (everything unlocked), build the unlocked behavior first and keep the lock hooks.

---

# Part A — Changes to existing screens

## A1. Game HUD (`GameHUD.tscn`) — ⚠ grid order superseded by E1
| | |
|---|---|
| ![](screenshots/01_hud_menu_bazaar_locked.png) | ![](screenshots/02_hud_bazaar_locked_tooltip.png) |
| `01` Menu: **My Mercday** (renamed) and new **My Bazaar**, locked | `02` Locked hover tooltip |
| ![](screenshots/03_hud_bazaar_lock_dialog.png) | ![](screenshots/04_hud_menu_bazaar_unlocked.png) |
| `03` Clicking a locked My Bazaar opens the lock dialog, **not** the window | `04` Unlocked |
| ![](screenshots/05_hud_bazaar_window.png) | |
| `05` Opens `BazaarViewer` in the standard SubWindow | |

- **CHANGED** MenuButton label **"My Subscription" → "My Mercday"** (icon/behavior unchanged).
- **NEW** 7th MenuButton **My Bazaar** (grid slot 7; 2 empty slots remain). Icon `assets/icons/hud_my_bazaar_16x16.png` (4 px per art pixel, like the others). Tooltip: "Buy gear for your mercs and track your orders".
- **NEW [LOCK]** MenuButton `locked` state (reusable for future buttons):
  - Background `#27324a`, bevel `#34415e`/`#1c2540`, icon `grayscale(1) brightness(0.55)`, label `#8a97ad`.
  - Lock badge top-right: 36×40 `#0a0f1c` box, 2 px `#3b4d6e` ring, 7×8 lock at 4 px in `#f2d33d`.
  - Tooltip: "Locked. Requires the Bazaar upgrade (Mercday Enterprise › Customize)."
  - Click → **FeatureLockDialog** (600 px, 4 px `#f2d33d` ring, 6 px-pixel lock, two lines, *Take Me There*). The window never opens while locked.
  - Copy: not Enterprise → "This feature of Mercday is not available on your plan!" / "Upgrade to **Mercday Enterprise** to use the Bazaar." · Enterprise without upgrade → "The Bazaar is locked." / "It requires the **Bazaar** upgrade!"
  - Take Me There → `GameState.go_to_plans({tab="customize", upgrade="bazaar", tier=1})` (Enterprise) or `{tab="plans"}`.

## A2. Contract Viewer — DecisionButtons
![](screenshots/06_contract_accept_reject.png)
`06` Accept is green, Reject is red, icons white.

| Button | bg | bevel hi / lo | hover | pressed |
|---|---|---|---|---|
| Accept | `#3f9a4a` | `#6cc36a` / `#2a6b32` | `#4fb05a` | `#2a6b32` |
| Reject | `#b8402e` | `#e8583f` / `#7a2a1e` | `#cc4a36` | `#7a2a1e` |
Label `#f3ead7` with a 2 px `#0a0f1c` text shadow. Check and X icons now `#f3ead7` (were green/red).

## A3. Metrics Viewer
| | |
|---|---|
| ![](screenshots/07_metrics_default_icon_tabs.png) | ![](screenshots/08_metrics_period_dropdown.png) |
| `07` Icon tabs attached to the chart panel; Period + Scale dropdowns | `08` Period dropdown |
| ![](screenshots/09_metrics_period_6m.png) | ![](screenshots/10_metrics_scale_dropdown_6m.png) |
| `09` Period = 6m | `10` Scale at 6m: all four valid |
| ![](screenshots/11_metrics_period_3y_scale_snapped.png) | ![](screenshots/12_metrics_scale_dropdown_3y.png) |
| `11` Days was selected → switching to 3y snapped it to **Months** | `12` Scale at 3y: Days/Weeks grayed |
| ![](screenshots/13_metrics_merc_all_mercs.png) | ![](screenshots/14_metrics_merc_selected.png) |
| `13` Merc Graph tab | `14` Merc selected |
| ![](screenshots/15_metrics_compare_picker.png) | ![](screenshots/16_metrics_compare_active.png) |
| `15` Compare picker | `16` Comparing |
| ![](screenshots/17_metrics_merc1_popup_while_comparing.png) | |
| `17` **Fix:** merc 1's list opens under merc 1's selector even while comparing | |

**Graph tabs → TabButton icon tabs** (same component as Merc Viewer):
- Active tab shows icon + label and expands; inactive tabs are 52 px icon-only with a tooltip of their name. Row height 44; active 44 tall, inactive 38, bottom-aligned.
- Tabs **sit directly on the chart panel** (no gap). Chart panel bevel: `inset 4px 0 0 #28447a, inset -4px -4px 0 #111c33`, outlines left/right/bottom `#0a0f1c`, top `#f28c28`. Embedded (Merc Viewer tab) keeps its 14 px gap.
- Icons (16×16 at 1.5 px, `metrics_tab_*_16x16.png`): Guild (banner), Contract (= HUD My Contracts), Merc (= HUD My Mercs). On the active orange tab, cream pixels render `#0a0f1c`.
- Locked tabs show the lock in place of the icon (TabButton `locked`).

**Period + Scale dropdowns** (replace the four scale buttons). Right side of the tab row, gap 16: [Show Averages] · `Period ▾` · `Scale ▾`.
- Button 30 px, min-width 92, `#2b4f8a` (open: `#3b6fb6`), Silkscreen 10 px, caret. Popup: right-aligned, min-width 112, `#1f3560`, 3 px `#f28c28` ring, hard shadow; rows 26 px. Selected row `#f28c28`/dark text; valid `#16233f`; invalid `#101a30` + `#4a5a78` text, `not-allowed`, tooltip with the reason. Outside click closes.
- **Period**: All Time *(default)*, YTD, 6m, 1y, 3y, 5y. Rules in DATA_DELTA §6.
- **Scale**: Days, Weeks, Months, Quarters. Days ≤ 6m · Weeks ≤ 1y · Months ≥ 6m · Quarters ≥ 1y (by the **effective span**). Changing Period with an invalid Scale **snaps to the nearest valid scale** (tie → the larger one). Default Scale = Months (or nearest valid).
- Locked graph: both dropdowns 0.4 opacity, `not-allowed`, tooltip "Locked".

**Fixes:** merc 1's popup is anchored to merc 1's selector (was anchored to the whole picker block, so it opened below the compare row). Popups `overflow-x: hidden`. List title never wraps.

## A4. Merc Viewer — Overview: Coaching + Lifepath
| | |
|---|---|
| ![](screenshots/18_merc_overview_coaching_lifepath.png) | ![](screenshots/19_coach_button_tooltip.png) |
| `18` **Coaching** label + **Coach** button + "Plan: Auto"; Lifepath visible again | `19` Coach tooltip |
| ![](screenshots/20_coach_dialog.png) | ![](screenshots/21_coach_option_tooltip.png) |
| `20` **CoachDialog** | `21` Option hover |
| ![](screenshots/22_coach_locked_option_tooltip.png) | ![](screenshots/23_coach_lock_icon_tooltip.png) |
| `22` Locked option hover (description only) | `23` Hovering the lock: **only** the FeatureLock tooltip shows |
| ![](screenshots/24_coach_changed_confirm_enabled.png) | ![](screenshots/25_merc_overview_plan_updated.png) |
| `24` New pick → Confirm enabled (green) | `25` Confirmed: "Plan: Support" |

- **FIX** Lifepath list was empty (template read a non-existent key). It now lists Lifepath events when `lifepath` is entitled.
- **REMOVED** the inline "Performance Improvement Plan" radio list and its section lock.
- **NEW** in its place: label **Coaching** (Silkscreen 9 px `#f28c28`), **Coach** button (40 px, `#2b4f8a`, whistle icon `coach_whistle_12x12.png` at 2 px, Silkscreen 11 px), and a line "Plan: <mode>" (12 px `#9cc6ef`, mode in `#f3ead7`). The Coach button is always enabled (Auto is always available).
- **CoachDialog** (modal, 600 px, same chrome as SalaryDialog: dim `rgba(6,10,20,.72)`, orange 4 px ring, red X):
  - Header: "Performance Improvement Plan" / merc name (orange 18 px) / "Choose how this merc focuses when they level up."
  - Groups (heading Silkscreen 9 px `#9cc6ef`), 3-column grid, gap 8:
    - **Standard**: Auto, Random, Utility, Stats — icon color `#9cc6ef`
    - **Combat PIP**: Support, Defensive, Offensive — `#e8583f`
    - **Skill PIP**: Skills, Existing Skills, New Skills, Universal, Ancestral, Tradition, Spell — `#6cc36a`
  - **PipModule** (44 px): 30×30 `#0a0f1c` icon box (8×8 icon at 3 px, `pip_*_8x8.png`) + name (Silkscreen 11 px). Selected: bg `#15223d`, 3 px `#f28c28` ring, orange name. Idle: `#0e1628`, 2 px `#2b4f8a`. The merc's current mode shows a "Current" tag (`#9cc6ef`, 7 px).
  - Locked module: `#101a30`, 2 px `#1f3560`, grey icon `#3b4d6e`, name `#5e7699`, `not-allowed`, FeatureLock at the right.
  - **Tooltips**: hovering a module shows its description (and "Current plan" on the current one). Hovering the **lock** hides the module tooltip so only the FeatureLock tooltip is visible.
  - Footer: **Cancel** | **Confirm**. Confirm is disabled (0.4) until the pick differs from the current mode; green (`#3f9a4a`) when enabled. Confirm writes `GameState.pip_modes[merc_id]`.
- **Mode text** (tooltips) is in DATA_DELTA §3.
- **Auto-revert [LOCK]:** if an upgrade is removed in Customize, every merc whose mode depended on it reverts to **Auto** (immediately, and permanently — re-buying doesn't restore it).

## A5. Subscription Viewer — Customize (big change) — ⚠ positions/routing superseded by E4 (rules for colors, gates and tooltips still apply)
| | |
|---|---|
| ![](screenshots/26_customize_default_view.png) | ![](screenshots/27_customize_full_map.png) |
| `26` Default view (centered on Base Plan) | `27` Whole map (zoomed out for this guide) |
| ![](screenshots/28_customize_top_coaching_limits_testing.png) | ![](screenshots/29_customize_middle_testing_lesslegal_insights.png) |
| `28` Top: Coaching, Limits, Testing | `29` Middle: Testing, Less Legal, Insights |
| ![](screenshots/30_customize_bottom_bazaar_metrics.png) | ![](screenshots/31_category_tooltip_upgrades_owned.png) |
| `30` Bottom: Bazaar, Metrics chain | `31` Category tooltip: "x/y upgrades owned" (white) |
| ![](screenshots/32_base_plan_tooltip.png) | ![](screenshots/33_skill_pip_tiers.png) |
| `32` Base Plan (My Mercday logo) | `33` Skill PIP now 5 tiers |
| ![](screenshots/34_odd_jobs_tiers.png) | |
| `34` NEW Odd Jobs (Less Legal) | |

**1. Layout is now rule-based.** Delete hand-placed positions and hand-routed connectors. Every node sits on a grid and every connector is generated from rules (DATA_DELTA §5 has the grid table and every rule). Summary:
- Grid: `x = 800 + col·135`, `y = 500 + row·70`. Siblings 2 rows apart; gated columns 2 cols apart.
- One exit point per side (center of that side). Multiple lines leaving the same side share it and fork later.
- Category spine sits halfway between the category box and its kids.
- Requirement modules `[have/need]` (52×26): sources converge **118 px** before the target; the module sits **33 px** from the target (the Criminal Background Check spacing is the standard minimum).
- A line that leaves through a label keeps a 10 px stub on the box, gaps for the text, then resumes.

**2. New / moved content**
- **NEW category Less Legal** (off the right trunk, between Testing and Insights) → **Odd Jobs**. Discrimination and Criminal Background Check **also count** toward Less Legal (totals + progress) but stay in Insights. Only **Discrimination** is linked from Less Legal (right, then down into its top).
- **NEW category Bazaar** (below Base) → **Bazaar** → Better Items / Faster Items (each needs Bazaar I).
- **Testing** moved right of Less Legal, on Base Plan's right line; tests centered on the category.
- **Education Exam** now needs **Aptitude Test + Background Check, 3 combined** (was Background Check 2).
- **Insights** order: Discrimination, (Criminal), Background Check, Metrics.
- **Metrics** (subcategory of Insights) now leads the survey chain: Merc Metrics → **Employee Survey** (needs Merc Metrics 1) → Peer Review; **Customer Satisfaction** needs Contract Metrics + Employee Survey (2); **Rapid Survey** needs Peer Review + Customer Satisfaction (2). No direct Employee Survey → Rapid Survey line.
- **RENAMED** Fast Metrics → **Rapid Survey** (id `fastmetrics` unchanged).
- **Skill PIP** 3 → **5 tiers** (new Tier 1 Existing Skills, Tier 2 New Skills). **Combat PIP** 2 → **3 tiers** (new Tier 1 Support). Magic PIP requirement unchanged (4 combined).
- Base Plan icon → **My Mercday logo**.

**3. Progress colors**
- **Icon color**: category icons and the Base Plan logo run **dark red → bright green** by progress (`catColor`, DATA_DELTA §4). Base Plan uses progress across **all** upgrades. At 100% the icon **glows** (the icon only, not its box).
- **Requirement modules** are stop points: text + ring use `gateColor(have/need)`; glow once met.
- **Line colors** (forward only):
  - From Base Plan: always orange `#f28c28`.
  - Out of a category: its icon color; a category with no progress passes the incoming color through (so untouched branches stay orange).
  - Out of an upgrade: its own progress color (unowned = start of the scale, dark red).
  - Into a requirement module: each source leg keeps its source's color and **fades (gradient) into the average** of the sources on its final segment; the merged leg is the average.
  - Out of a requirement module: the module's color.
  - Lines are **50 % opacity** when the element they lead to is not yet available.
- Category tooltip adds "x/y upgrades owned" in `#f3ead7`.

**4. One pulse clock** — see Part B4. All glows/shines on this screen now read one shared signal.

---

# Part B — Dependencies (build before Part C)

## B1. Entitlements (`SubscriptionManager.entitlements()`)
Add/renumber these keys (full table in DATA_DELTA §2):
- `lvSupport` combatpip≥1, `lvDefensive` ≥2, `lvOffensive` ≥3 *(renumbered)*
- `lvExisting` skillpip≥1, `lvNewSkills` ≥2, `lvUniversal` ≥3, `lvAncestral` ≥4, `lvTradition` ≥5 *(renumbered)*
- `oddJobs: int` = oddjobs tier (max mercs on Odd Jobs; ≥1 also unlocks the **Odd Job Default Bonus** setting — Settings page TBD)
- `bazaar: bool` = bazaar ≥ 1
- `bazaarRarity: int` = betteritems tier (0 Ordinary only … 4 Very Rare)
- `bazaarSpeed: int` = fasteritems tier (delivery days table in DATA_DELTA §7)

## B2. GameState additions
```gdscript
var pip_modes: Dictionary = {}        # merc_id -> StringName mode; missing = &"Auto"
func prune_pip_modes() -> void        # on SubscriptionManager.changed: drop modes whose entitlement is gone (→ Auto)
# Bazaar lives in its own autoload (BazaarManager, SCENES_DELTA) but spends GameState.money.
```

## B3. TabButton — icon size props
`@export var icon_cols: int = 12` and `@export var icon_px: float = 2.0`. Metrics uses 16 cols at 1.5 px (so the 16×16 HUD icons fit the same 24 px box).

## B4. PulseClock (autoload) — one tick for all glows
Replace every looping per-item Tween/AnimationPlayer glow with **one** clock:
```gdscript
# PulseClock.gd (autoload). One cycle = 1.6 s. Shape: rise 0→1 over 0–14 %, fall to 0 by 50 %, rest until 100 %.
signal pulse(g: float, sweep: PackedFloat32Array)   # sweep[i] = same shape delayed i × 0.14 s (i = 0..7)
func shape(x: float) -> float: return x / 0.14 if x < 0.14 else (1.0 - (x - 0.14) / 0.36 if x < 0.5 else 0.0)
```
Consumers set a shader uniform (or `modulate`) from `g`:
- **Whole-item glow** (complete category icon, Base logo at 100 %, met requirement module, maxed tier icons in the tier dialog): brightness `1 + g·0.8`, gold glow `rgba(242,211,61, g·0.9)` radius `g·6 px`.
- **Left→right sweep** (maxed mini tier bar chunks, full tier bar in the dialog): chunk *i* uses `sweep[i]`, brightness `1 + s·0.9` (+ glow radius `s·7 px` in the dialog bar).
- One-shot effects (reject shake, tier up/down flash) stay as one-off tweens.

## B5. Shared components reused by the Bazaar
TabButton (with `badge`), FeatureLock (rarity locks), LockedPage (inside Bazaar), ConfirmDialog chrome, notes glyph.

---

# Part C — Fresh build-out: My Bazaar

## C1. Upgrades (Customize › Bazaar)
| | |
|---|---|
| ![](screenshots/35_bazaar_better_items_tiers.png) | ![](screenshots/36_bazaar_faster_items_tiers.png) |
| `35` Better Items (4 tiers × 5 n) | `36` Faster Items (5 tiers × 2 n) |

| id | Name | Tiers | Monthly | Requires |
|---|---|---|---|---|
| `bazaar` | Bazaar | 1: Unlock the Bazaar (orders take 20 days) | 10 *(placeholder)* | — |
| `betteritems` | Better Items | Common · Uncommon · Rare · Very Rare | 5 each | Bazaar 1 |
| `fasteritems` | Faster Items | 25 % (15 d) · 30 % (14 d) · 45 % (11 d) · 50 % (10 d) · 2-Day | 2 each | Bazaar 1 |
Icons: `customize_bazaarCat/bazaar/betteritems/fasteritems_12x12.png`.

## C2. Screen: `BazaarViewer.tscn` (1280×720, SubWindow from HUD)
Layout: tab row (44 px, TabButtons **Orders · Cart · Shop**, Shop opens by default) sitting directly on the content panel (same attachment as Metrics). Content panel padding 16. Tab badges: Cart = item count, Orders = in-transit count (orange `#f28c28`).

### Shop
| | |
|---|---|
| ![](screenshots/37_bazaar_shop_default.png) | ![](screenshots/38_bazaar_department_weapons.png) |
| `37` Default: All Departments, 5-column grid | `38` Department selected → Type filter appears |
| ![](screenshots/39_bazaar_subtype_filter.png) | ![](screenshots/40_bazaar_sort_dropdown.png) |
| `39` Subtypes checked | `40` Sort dropdown |
| ![](screenshots/41_bazaar_filters_no_results.png) | ![](screenshots/42_bazaar_add_to_cart_qty.png) |
| `41` No results (filters) | `42` Add to Cart → − qty + control |
| ![](screenshots/43_bazaar_search_no_results.png) | |
| `43` No results (search) | |

- Grid `250px | 1fr`, gap 16.
- **FilterPanel** (left, `#0e1628`, 2 px `#1f3560`, scrolls): sections headed Silkscreen 11 px orange:
  1. **Department** — All Departments + 7 (Weapons, Armor, Headwear, Containers, Tools, Consumables, Trinkets). 26 px rows, count at right; selected `#f28c28`/dark.
  2. **<Department> Type** (only when a department is picked) — checkbox per subtype with counts. None checked = all.
  3. **Price** — radios: Any Price, Under 50, 50 to 150, 150 to 400, 400 & Above; plus custom **Min – Max** + **Go** (custom range overrides the preset; its inputs ring orange while active).
  4. **Rarity** — checkbox per rarity in its color; none checked = all unlocked. Rarities above `bazaarRarity` are **locked** (grey box + FeatureLock "Better Items, tier N").
  5. "Clear all filters" link (only when any filter is active).
- **Top bar**: search field (36 px, `#0a0f1c`, 2 px `#3b6fb6`, clear X, orange search button), **Sort by** dropdown (Featured, Price: Low to High, Price: High to Low, Rarity: Highest First, Name: A to Z).
- Breadcrumb ("Weapons › Swords, Bows › "query"") + "N results".
- **ItemCard** (5 cols, gap 12, `#0e1628`, 2 px `#1f3560`, padding 8): **square** image slot (1:1, `#15223d` with the equipment-slot stripe, 2 px ring in rarity color, rarity tag top-left), name (Silkscreen 700 11 px), "Subtype · Department", price + notes glyph (Silkscreen 700 16 px), "Arrives <date> (N days)" in green, **Add to Cart** (30 px orange). In cart: `− N +` control (green ring, number only).
- Empty state: "No items match your filters" + "Try a different department, price, or rarity." + Clear all filters.

### Cart + Checkout
| | |
|---|---|
| ![](screenshots/44_bazaar_cart.png) | ![](screenshots/45_bazaar_checkout_dialog.png) |
| `44` Cart | `45` Checkout dialog |
| ![](screenshots/46_bazaar_order_placed.png) | ![](screenshots/50_bazaar_cart_empty.png) |
| `46` Order placed | `50` Empty cart |
| ![](screenshots/51_bazaar_cart_cant_afford.png) | |
| `51` Can't afford: checkout disabled + red reason | |

- Grid `1fr | 300px`.
- **CartList**: "Shopping Cart" + "N items". Rows: 64 px square image, name, "Rarity · Subtype · Department", arrival, Remove link, `− qty +`, line total + "x each".
- **OrderSummary**: Items (N), Delivery **Free**, Arrives, Your Notes; **Order Total** (orange 18 px); Notes After Purchase (green / red). **Proceed to Checkout** (46 px green) — disabled (0.4) if the cart is empty or total > notes; the reason shows under it in red ("Not enough notes. Remove items or earn X more.").
- **CheckoutDialog** (520, green ring): line list, Subtotal / Delivery / Estimated Arrival / Notes After Purchase, **Cancel** | **Place Order** (green). Place Order spends notes, clears the cart, creates an order.
- **Order Placed** dialog: "Order #N will arrive <date> (N days)." **Keep Shopping** | **View Orders**.

### Orders
| | |
|---|---|
| ![](screenshots/47_bazaar_orders_all.png) | ![](screenshots/48_bazaar_orders_in_transit.png) |
| `47` All | `48` In Transit |
| ![](screenshots/49_bazaar_orders_delivered.png) | |
| `49` Delivered | |

- Filters: All (n) · In Transit (n) · Delivered (n). Newest first.
- **OrderCard**: header strip (Order Placed, Total, Items, Order #) · status title ("Arriving Jul 21" orange / "Delivered Jun 3" green) + sub ("N days left · Day x of y" / "Delivered to Guild Storage") · 20-cell progress bar (filled = elapsed/days) with "Ordered …" / "Arrives …" under it · item chips (32 px image, name, "Rarity · ×qty").

### Locked
If `entitlements.bazaar` is false the HUD never opens the window (A1). The viewer still has its own LockedPage overlay for safety (same copy as A1).

---

# Part D — Verify Bazaar (click-through)
1. HUD shows **My Mercday**; My Bazaar is locked on Free/Pro and on Enterprise without the upgrade. Clicking it opens the lock dialog only; Take Me There lands on the Bazaar upgrade.
2. Buy Bazaar I → button unlocks → window opens on **Shop**.
3. Shop: pick Weapons → Type filter appears; check two subtypes; set 50–150; counts and results update; Clear all filters resets.
4. Rarity: with Better Items 2, Rare and Very Rare are locked; buy tier 3 → Rare unlocks.
5. Add items; the Cart tab badge counts them; exceed your notes → checkout disabled with the red reason.
6. Place an order → notes drop, cart empties, Orders shows it "Arriving" with a partly filled bar. Buy Faster Items 5 → new orders show 2-Day.
7. Metrics: Period 6m → all scales valid; pick Days → switch to 3y → Scale snaps to Months.
8. Merc Viewer: Lifepath lists events; Coach → pick Support → Confirm → "Plan: Support"; remove Combat PIP in Customize → merc shows "Plan: Auto".
9. Customize: the merged leg into Criminal Background Check's `[x/6]` is the blend (olive) when one parent is green and the other red; lines out of unmet modules are 50 %; completing Limits makes its icon glow in sync with every other glow.

---

# Part E — More changes to existing screens

## E1. Game HUD — 3×3 menu re-layout + My Promotions (`GameHUD.tscn`)
| | |
|---|---|
| ![](screenshots/52_hud_menu_new_layout_promotions_locked.png) | ![](screenshots/53_hud_promotions_locked_tooltip.png) |
| `52` New 3×3 order. My Promotions locked (non-Enterprise) | `53` Locked tooltip |
| ![](screenshots/54_hud_promotions_lock_dialog.png) | ![](screenshots/55_hud_menu_enterprise_unlocked.png) |
| `54` Click locked → FeatureLockDialog, "Take Me There" → Plans | `55` Enterprise: unlocked |
| ![](screenshots/56_hud_promotions_window.png) |  |
| `56` Opens PromotionsViewer in the standard SubWindow |  |

- **CHANGED grid (row-major, 9 of 9 slots, no empty slots):**
  1 My Mercs · 2 My Contracts · 3 My Clients
  4 **My Promotions (NEW)** · 5 My Mercday · 6 **My Finance** (moved from 4)
  7 **My Legal** (moved) · 8 **My Bazaar** (moved) · 9 **My Metrics** (moved)
- **NEW MenuButton My Promotions** — icon `hud_my_promotions_16x16.png` (megaphone), label "My Promotions". **[LOCK]** `entitlements.promotions` (true only on Enterprise). Locked = same treatment as locked My Bazaar: bg `#27324a`, inset hi `#34415e` / lo `#1c2540`, icon `grayscale + brightness 0.55`, label `#8a97ad`, yellow 7×8 lock badge (4 px cells, `#f2d33d`) top-right. Tooltip locked: "Locked. Requires Mercday Enterprise." Unlocked: "Run ad campaigns and hire mercs who apply". Lock dialog copy: "This feature of Mercday is not available on your plan!" / "Upgrade to **Mercday Enterprise** to use Promotions." → Take Me There = Plans tab.
- **CHANGED My Legal icon** → `hud_my_legal_gavel_16x16.png`: all-white gavel, angled, striking its block (was brown/grey).
- **FIX tooltips on top:** a hovered MenuButton gets `z_index 25` so its tooltip is never covered by the next row or the bottom bar; the menu grid container sits above the bottom bar (`z 3`).
- **My Finance dot** now also lights when any applicant is unseen (`PromotionsManager.has_unseen()`), in addition to loan offers.

## E2. Finance Viewer — Hiring tab + Odd Jobs gate (`FinanceViewer.tscn`)
- **NEW tab "Hiring"** between Payroll and Invest (icon `finance_tab_hiring_12x12.png`, title "Review mercs who applied to your guild"). Content = `HiringTab.tscn` (Part G2). Tab dot = any unseen applicant. Available on **all plans** (walk-ins exist without Promotions).
- **FIX Request a Loan › Send Mercs:** envoy slots = `entitlements.oddJobs` (tier = max mercs, 0 = locked). With 0, the Send Mercs box shows a single locked **"Add Merc"** button (FeatureLock label mode, 150×40) that opens the lock dialog for **Odd Jobs** (Less Legal). The loan request itself still works without envoys. ![](screenshots/87_finance_request_loan_oddjobs_locked.png) `87`

## E3. Merc Viewer
- **FIX XP tooltip stuck open:** the Level badge tooltip has `mouse_filter = IGNORE` and closes immediately on mouse exit (no 350 ms linger).
- **NEW applicant mode** (`@export var applicant: ApplicantData`, `hide_roster = true`): identity comes from the applicant; **Coaching, Salary module and the Metrics tab are greyed (opacity 0.4, grayscale) and not clickable**. Used by Hiring › View (`83`).

## E4. Subscription Viewer — Customize tree re-layout (supersedes A5 layout)
| | |
|---|---|
| ![](screenshots/88_customize_default_view.png) | ![](screenshots/89_customize_full_map.png) |
| `88` First open: view centered on Base + every top-level category | `89` Full map (zoomed out for the guide only) |
| ![](screenshots/90_customize_legal_lesslegal.png) | ![](screenshots/91_customize_insights_metrics.png) |
| `90` Legal + Less Legal branches | `91` Insights → Background Check → Metrics / Criminal BG Check |

- **Module size** 92×92 (Base 100×100) so a 9-tier pip bar fits with padding. Grid pitch **GX 150 / GY 84** px. World 4600×2900, Base at x 2600.
- **Base exits:** left-upper → **Limits** (arm leaves Base's left edge 30 px above center, turns up halfway, runs into Limits' right side); left-lower → **Bazaar** (mirror, 30 px below). Both arms share one elbow x. Top → **Coaching**. Right → **Testing** (level with Base; Aptitude on the same line). Bottom: one drop, then **two branches** — left branch splits to **Legal** + **Less Legal**, right branch to **Insights**.
- **Insights** → Background Check → Metrics (Contract/Merc Metrics → Employee Survey → Customer Satisfaction / Peer Review → Rapid Survey) runs to the right. Criminal Background Check needs Discrimination + Background Check (merge box).
- **Less Legal** fork: Who Knows a Guy · Odd Jobs · Discrimination (evenly spaced, one bar). Advisory Counsel sits under Odd Jobs; Representation's line runs straight across into its merge row.
- **Exact coordinates + category routing:** port `place` and `catDefs` from `reference_html/Subscription Viewer.dc.html` verbatim (also listed in DATA_DELTA §8).
- **One line renderer (no per-line code):** every requirement leg is ONE polyline (list of points) drawn in its source color that fades into the merged color over its **last non-zero segment** only. Routing only chooses points. `exitDy` offsets a source's side exit so two requirements leaving the same side run as separate parallel lines (Aptitude → Skill Test −18 px, Aptitude → Education Exam +18 px). `topExit` / `sideExit` choose the exit side.
- **Cost attribution:** an upgrade fed by several categories bills its cost to exactly one: Advisory Counsel → Legal, Criminal Background Check → Insights, Education Exam → Testing.
- **Base module bars** are drawn inside an inset "tube" (dark well + highlight) and sit lower with padding.
- **Removed** Faster Items tier notes "(15 days)" etc.; tiers read "Deliveries arrive 25% faster", …, "2-Day delivery on all items".
- **New upgrades** (Legal branch, Who Knows a Guy, Advisory Counsel, Discrimination IV, Skill Test req): see DATA_DELTA §1.

## E5. Shared components (build before F/G)
- **NotificationDot** — one style everywhere: round red dot, no counts, no square/colored variants. Tabs render in reverse order (`row-reverse`) so a tab's top-right dot is never covered by its right-hand neighbour.
- **FeatureLock label mode** — `@export var label: String`: renders the whole locked control as a greyed button (label + 7×8 lock, 2 px cells), bg `#27324a`, text `#8a97ad` Silkscreen; **any click opens the lock dialog**.
- **OddJobCrew.tscn (NEW)** — the one Odd Job setup, identical to Request a Loan: Send Mercs (EnvoySlot ×max, dashed empty slots 84×84, picker sorted by fit) + Pay Mercs (default bonus, QuantityStepper per merc, Total in red if > notes). Used by Legal (Renegotiate / Break Out), Promotions (Word of Mouth) and Hiring (counter-offer).
- **TextEntryDialog.tscn (NEW)** — on-screen keyboard (rows: 1–0 · QWERTYUIOP · ASDFGHJKL' · Shift ZXCVBNM Del · - _ . , ! ? & # @ ( ) · Space), physical keyboard also works (Enter = Done, Esc = Cancel). Max length prop (64 for campaign names), counter "n / 64" turns `#e8583f` at max. Symbol keys use Pixelify Sans 18 px (Silkscreen lacks & # @).
- **ConfirmDialog** — every notes-spending action confirms first (permit request, pay fine, pay bail, hire, end campaign, reject applicant). Rich variant for Pay Fine / Pay Bail: kicker (Fine/Bail · Crime · Location), mercs involved, money breakdown, green outcome box with checkmark ("The fine is marked paid." / "<Merc> is released from <Location> and returns to your guild." + whether Good Standing is restored). CTA shows the amount ("Pay 495"). Dialogs under a confirm hide their close X.

---

# Part F — Fresh build-out: My Legal (`LegalViewer.tscn`, 1280×720 SubWindow from HUD)
Data: `LegalManager` autoload (SCENES_DELTA, DATA_DELTA §9). Placeholder names only: "Crime N", "Location N", "Nation N", "Rule N".

Tabs (TabButton ×3, row-reverse so dots stay on top): **Permits** (first) · **Fines** · **Bailout**. Tab dot = any unread fine (Fines) / unread capture (Bailout). HUD My Legal dot = either.

## F1. Permits
| | |
|---|---|
| ![](screenshots/57_legal_permits.png) | ![](screenshots/58_legal_permit_request.png) |
| `57` Horizontal slider of location cards | `58` Request dialog |
| ![](screenshots/59_legal_permit_confirm.png) | ![](screenshots/60_legal_request_violations.png) |
| `59` Confirm before paying | `60` Violations list (Review each) |
| ![](screenshots/61_legal_request_locked.png) |  |
| `61` [LOCK] permit tier too low: whole button opens lock dialog |  |

- Header "Permits" (Silkscreen 16 `#f28c28`) + "Buy Operation permits to expand your guild into different locations" (Pixelify 14 `#9cc6ef`). No other header copy.
- **HScrollContainer** of `LocationCard` (330 px wide, full height, gap 14, ~3.5 visible). Mouse wheel scrolls horizontally. Scrollbar = standard orange thumb with **pixel arrow buttons at both ends** (orange 3-step arrows on `#0a0f1c`, hover `#15223d`). No floating arrow buttons.
- **LocationCard** (top → bottom): location icon (larger than standard, placeholder hatch; "Home" tag on the home location) · name (Silkscreen 13) + nation · **Average Difficulty** (5 stars, contract difficulty colors, numeric value right) · **Rules** (Rule 1–3 bullets) · **Your Permissions** ×3 with ✓ `#6cc36a` / ✗ `#e8583f`: Operations Permit ("Grants the right to conduct business in this location."), Teleportation Permit ("Grants the right to use a teleportation circle to venture to/from this location."), Good Standing ("No fines or captured mercs." or "N violations in this location.") · **Request** button (orange).
- **PermitRequestDialog:** kicker "Request · Nation", title location. One row per permit: title + description + price (notes glyph) + **Request** (green) — or "Active"/"Home" when owned — or locked label button when `opsPermits`/`teleport` tier < location scope. **Good Standing** section: "In Good Standing" or "N violations", then a ViolationRow per open fine/capture (tag Fine/Captured, crime, amount/days, **Review** → opens that Review dialog on top).
- **Permits are kept forever.** If the upgrade lapses, owned permits show inactive (benefits off) but are never re-bought.

## F2. Fines
| | |
|---|---|
| ![](screenshots/62_legal_fines.png) | ![](screenshots/63_legal_fine_review.png) |
| `62` Outstanding list, dot per unread fine | `63` Review dialog |
| ![](screenshots/64_legal_fine_pay_confirm.png) | ![](screenshots/65_legal_fine_renegotiate_oddjob.png) |
| `64` Pay Fine confirm (rich) | `65` Renegotiate = Odd Job (OddJobCrew) |
| ![](screenshots/66_legal_review_locked.png) |  |
| `66` [LOCK] Odd Jobs 0 → Renegotiate locked; Relationship locked |  |

- Header "Fines" + "N outstanding · X notes owed". Toggle **Outstanding | Paid**. Row: location + crime · Total Due (notes) · due status ("N days past due" `#e8583f` / "In N days") · **Review**. Each unread fine has its own NotificationDot (top-left of the row); opening Review marks it read.
- **Review dialog:** kicker "Fine · Crime N", title location. Left: **Mercs Involved** as hoverable merc modules (same as the active-contract team: role strip, portrait, hover card with name, tradition sigil, level badge, contract match stars) · facts (Where, Issued, Due, Past Due). Right: **Contract** module (name, difficulty stars, reward, "View Contract" link → opens that contract) · **Relationship** with the location (11-face meter, [LOCK] `clientOpinion`). Money: Base Fine · Late Fees (N days × fee) · **Total Due**. Actions: **Renegotiate** (Odd Job) | **Pay Fine** (confirm first). In-progress Odd Job replaces the actions with a progress bar ("Renegotiating · names").

## F3. Bailout
| | |
|---|---|
| ![](screenshots/67_legal_bailout.png) | ![](screenshots/68_legal_bail_review.png) |
| `67` Captured mercs | `68` Review |
| ![](screenshots/69_legal_bail_pay_confirm.png) |  |
| `69` Pay Bail confirm |  |

- Row: merc portrait + name, location · crime, **Time Served**, **Time Remaining**, Bail, **Review**. Review: same layout (Captured Merc module, Held At, Sentence "N days of M days", Custody Fees (N days × 5)). Actions: **Break Out** (Odd Job) | **Pay Bail**.

## F4. Odd Jobs in Legal
- Renegotiate / Break Out open the shared `OddJobCrew` (E5) in an OddJobWindow with facts (Location, Crime, Total Due or Time Remaining, Duration 12 days) + Success Odds bar (20 cells) + outcome line. Pay is due up front.
- Outcomes (DATA_DELTA §9): Renegotiate success halves the fine, failure raises it 25%. Break Out success frees the merc with no bail, failure raises bail 50%.
- Advisory Counsel adds its % per merc to Renegotiate odds (shown as "Advisory Counsel: +N% per merc").

---

# Part G — Fresh build-out: My Promotions + Finance › Hiring
Shared data + filter logic: `PromotionsManager` autoload (port of `reference_html/promo-core.js`). Placeholders only ("Company N", "Event N", "Type N", "Location N", "Ancestry N", …).

## G1. My Promotions (`PromotionsViewer.tscn`) — [LOCK] Enterprise
| | |
|---|---|
| ![](screenshots/70_promo_advertise_job.png) | ![](screenshots/71_promo_advertise_guild.png) |
| `70` Tab Advertise Job: running job postings | `71` Tab Advertise Guild: running guild promos |
| ![](screenshots/72_promo_builder_job_locked.png) | ![](screenshots/73_promo_builder_job_identity_open.png) |
| `72` New Campaign (job): locked types + grouped filters | `73` Identity group open (unlocked) |
| ![](screenshots/74_promo_builder_job_word_of_mouth.png) | ![](screenshots/75_promo_builder_guild.png) |
| `74` Word of Mouth = Odd Job crew | `75` New Campaign (guild): difficulty stars + modules |
| ![](screenshots/76_promo_builder_guild_sponsorship.png) | ![](screenshots/77_promo_builder_guild_word_of_mouth.png) |
| `76` Sponsorship: pick one sponsor | `77` Guild Word of Mouth |
| ![](screenshots/78_promo_name_text_entry.png) | ![](screenshots/79_promo_end_campaign_confirm.png) |
| `78` Name Your Campaign typing screen | `79` End Campaign confirm |

- **Tabs:** Advertise Job (megaphone) · Advertise Guild (flag). Active tab icon draws in two dark tones (`#0a0f1c` / `#5a3510`) so it reads on orange.
- **CampaignCard** (3-column grid): type icon + name + type · targeting summary (up to 4 rows) · Time Remaining bar (20 cells) · Applicants (job) / Contracts Received (guild) · **View Applicants** (job → Finance › Hiring filtered to this campaign) · **End Campaign** (red, confirm, no refund).
- **"+ New Campaign"** bottom-right, same style as "+ Request a Loan".
- **CampaignBuilder** (1190×660): left = 5 campaign types (icon, name, price line, quality stars 1–5); earlier rows paint above later ones so lock tooltips open downward on top. Right config panel: **Campaign Name** field (opens TextEntryDialog, 64 max, default "Campaign N") + **Duration (days)** stepper (min 1, max 90) at the top, then targeting. Footer: reason (red) · cost note · cost · **Launch Campaign** (disabled with reason).
- **Job targeting** = grouped, collapsible **FilterGroups** with active-count badge: **Value** (Salary Request range slider), **Identity** (Tradition, Ancestry, Bloodline, Heritage, Criminality), **Physical** (Age range, Min Speed, Min Vigor, Min Dexterity), **Mental** (Min Cognition, Min Wile, Knowledges, Tools). Any trait you can't view shows a locked "Locked" button naming its upgrade. Ancestry/Bloodline/Age also need **Hiring Discrimination** (Discrimination IV). Note: "Applicant level can't be targeted."
- **Guild targeting:** (Direct Sale / Sponsorship) **Advertise To / Sponsor** single-pick chips (required) · **Difficulty**: two rows of 5 clickable stars, **Min** and **Max**, half-star steps (left half = n−0.5); colors = contract difficulty colors by value; hover previews on the star pixels only · **Contract Type** and **Locations** side by side, each a fixed-height scroll box with a 2-wide grid of modules: [square image 64×64][Received / Completed / Failed (+ Relationship for locations, [LOCK] clientOpinion)] then name. Locations without an Operations Permit are greyed and not clickable ("No Operations Permit"). Note: "Level and reward can't be targeted." (Locations label: "sets roughly how far contracts are").

## G2. Finance › Hiring (`HiringTab.tscn`)
| | |
|---|---|
| ![](screenshots/80_finance_hiring.png) | ![](screenshots/81_finance_hiring_sort_dropdown.png) |
| `80` Applicants + filters; dot = new applicant | `81` Sort dropdown + direction |
| ![](screenshots/82_finance_hiring_filters_identity.png) | ![](screenshots/83_finance_hiring_applicant_view.png) |
| `82` Grouped filters, locked traits | `83` View → Merc Viewer (applicant mode) |
| ![](screenshots/84_finance_hiring_offer.png) | ![](screenshots/85_finance_hiring_counter_offer.png) |
| `84` Offer at/above asking | `85` Below asking = counter-offer |
| ![](screenshots/86_finance_hiring_hire_confirm.png) |  |
| `86` Hire confirm |  |

- Left (290 px): **Filters** with Clear; same FilterGroups as the job builder plus **Applied Via** (campaign chips + **Walk-In**). Salary Request is a two-ended range slider (0–2,000 / mo, step 50).
- Right: "Applicants" + "N of M applicants shown" · **Sort** dropdown (Uniqueness, Fit, Level, Salary) + ▲/▼ direction button.
- **ApplicantCard** (3-column grid): portrait, name, tradition sigil + name, LVL badge · rows: Salary Request, Uniqueness ("N · Rare"), Fit (stars), Applied Via, plus Ancestry/Bloodline/Age/Heritage when viewable · status line (counter-offer sent / refused) · **Reject | 👁 View | Offer**. NotificationDot while unseen (cleared by View, Offer or Reject).
- **HireOfferDialog:** facts (Tradition, Level, Asking, Your Offer %, **Merc Slots**) · amount stepper + quick picks Asking / +10% / +25% / +50% / +100% · Guild Opinion on Hire ([LOCK] Employee Survey) · hint. Offer ≥ asking → "Hire for X / mo" → confirm → hired. Offer < asking → **counter-offer**: OddJobCrew (or locked "Add Merc") + Success Odds; send → card shows "Counter-offer sent…" → resolves after a delay (hire or "Refused your counter-offer").
- Hiring needs a free merc slot (Offer disabled with "No free merc slots.").

---

# Part H — Verify (E–G click-through)
1. HUD: 3×3 order matches E1; hover each button — tooltip always on top. Non-Enterprise: My Promotions greyed + lock; click → lock dialog. Enterprise: opens Promotions.
2. HUD dots: My Legal (unread fine/capture), My Finance (loan offer or unseen applicant).
3. Legal › Permits: cards scroll horizontally (wheel + pixel arrow buttons). Request → dialog → Request → **confirm** → permit becomes Active; notes deducted. Low tier → locked label button opens lock dialog.
4. Legal › Fines: each unread row has a dot; Review marks read. Review shows merc modules (hover card), contract module + link, relationship (or lock), late fees. Pay Fine → rich confirm → paid (moves to Paid). Renegotiate → OddJobCrew; Odd Jobs 0 → locked.
5. Legal › Bailout: Time Served / Time Remaining; Pay Bail confirm → merc released; Break Out = Odd Job.
6. Promotions: Advertise Job / Advertise Guild tabs; + New Campaign bottom-right. Builder: name field opens keyboard (64 max); Duration min 1; groups collapse/expand with counts; locked traits show lock buttons; Direct Sale disabled on Advertise Job; guild difficulty half-stars with contract colors; Contract Type / Locations boxes scroll independently, no page scroll; no-permit locations greyed. Launch deducts cost; End Campaign confirms.
7. Finance › Hiring: tab dot while unseen applicants; filters (incl. Walk-In) and sort dropdown work; View opens applicant Merc Viewer with Coaching/Salary/Metrics greyed; Offer at asking → confirm → hired (+1 opinion, slot used); below asking → counter-offer with odds + crew; no free slot → Offer disabled.
8. Finance › Request a Loan: Odd Jobs tier caps envoy slots; 0 → locked "Add Merc".
9. Customize: first open shows Base + all categories; Limits/Bazaar arms mirror; Legal/Less Legal/Insights hang from the two bottom branches; every merge leg fades only on its last segment; Aptitude has two parallel exits.
